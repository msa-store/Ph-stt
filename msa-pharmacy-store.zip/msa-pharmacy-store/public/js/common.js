(function () {
  'use strict';
  const $ = (s, r) => (r || document).querySelector(s);
  const esc = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const nf = new Intl.NumberFormat('ar-EG', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
  const money = (n) => nf.format(Number(n)) + ' ج.م';
  const PLACEHOLDER = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400"><rect width="400" height="400" fill="#eef0f5"/><g fill="none" stroke="#9aa5ba" stroke-width="8" stroke-linecap="round"><rect x="130" y="120" width="140" height="170" rx="18"/><path d="M165 120v-30h70v30M200 180v70M165 215h70"/></g><text x="200" y="345" text-anchor="middle" font-family="sans-serif" font-size="26" fill="#7b869b">صورة تجريبية</text></svg>');
  const img = (src) => esc(src || PLACEHOLDER);
  document.addEventListener('error', (e) => {
    const t = e.target;
    if (t && t.tagName === 'IMG' && !t.dataset.fb) { t.dataset.fb = '1'; t.src = PLACEHOLDER; }
  }, true);

  async function api(path, opts) {
    const o = opts || {};
    let res;
    try {
      res = await fetch(path, { method: o.method || 'GET', headers: { 'Content-Type': 'application/json' }, body: o.body ? JSON.stringify(o.body) : undefined });
    } catch (_) { throw new Error('تعذر الاتصال بالخادم. تحقق من الإنترنت وحاول مرة أخرى.'); }
    let data = null;
    try { data = await res.json(); } catch (_) { /* empty */ }
    if (!res.ok) {
      const e = new Error((data && data.error && data.error.message) || 'حدث خطأ غير متوقع');
      e.status = res.status;
      e.fields = data && data.error && data.error.fields;
      e.details = data && data.error && data.error.details;
      throw e;
    }
    return data;
  }

  function toast(msg) {
    const t = document.createElement('div');
    t.className = 'toast'; t.setAttribute('role', 'status'); t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 2600);
  }

  // ---------- السلة (تخزين محلي للعرض فقط؛ الأسعار تُحسب وتُتحقق على الخادم) ----------
  const KEY = 'msa_cart_v1';
  let cart = {};
  try { const o = JSON.parse(localStorage.getItem(KEY) || '{}'); if (o && typeof o === 'object') cart = o; } catch (_) { cart = {}; }
  const items = () => Object.values(cart);
  function persist() {
    try { localStorage.setItem(KEY, JSON.stringify(cart)); } catch (_) { /* private mode */ }
    const n = items().reduce((s, i) => s + i.qty, 0);
    const b = $('#cartCount'); if (b) { b.textContent = n; b.hidden = n === 0; }
  }
  function addToCart(p, qty) {
    if (!p || p.stock < 1) { toast('هذا المنتج غير متوفر حاليًا'); return; }
    const cur = cart[p.id] ? cart[p.id].qty : 0;
    const want = cur + (qty || 1);
    const qn = Math.min(want, p.stock);
    cart[p.id] = { id: p.id, name: p.name, price: p.price, oldPrice: p.oldPrice, imageUrl: p.imageUrl, stock: p.stock, qty: qn };
    persist();
    toast(want > p.stock ? 'الكمية المتاحة فقط ' + p.stock : 'تمت الإضافة إلى السلة');
  }

  // ---------- واجهة السلة وإتمام الطلب ----------
  let config = { storeName: 'صيدليات محمد سعد', whatsappNumber: '201010031279' };
  let view = 'cart', lastOrder = null, notice = '', formErr = null, form = { name: '', phone: '', address: '' }, pendingKey = null, pendingSig = null, busy = false;
  const rid = () => Array.from(crypto.getRandomValues(new Uint8Array(16)), (b) => b.toString(16).padStart(2, '0')).join('');
  const waLink = (text) => 'https://wa.me/' + config.whatsappNumber + (text ? '?text=' + encodeURIComponent(text) : '');

  function orderMessage(o) {
    const lines = o.items.map((i, k) => (k + 1) + ') ' + i.name + ' × ' + i.quantity + ' = ' + i.lineTotal.toFixed(2) + ' جنيه');
    return ['طلب جديد من ' + config.storeName, 'رقم الطلب: #' + o.id, 'الاسم: ' + o.customerName, 'الهاتف: ' + o.customerPhone, 'العنوان: ' + o.customerAddress, '', 'المنتجات:', ...lines, '',
      o.discount > 0 ? 'إجمالي الخصم: ' + o.discount.toFixed(2) + ' جنيه' : null, 'الإجمالي: ' + o.total.toFixed(2) + ' جنيه مصري'].filter((x) => x !== null).join('\n');
  }

  function ensureDrawer() {
    if ($('#cartDrawer')) return;
    const ov = document.createElement('div'); ov.className = 'overlay'; ov.id = 'overlay'; ov.hidden = true;
    const d = document.createElement('aside'); d.className = 'drawer'; d.id = 'cartDrawer'; d.hidden = true;
    d.setAttribute('role', 'dialog'); d.setAttribute('aria-label', 'سلة المشتريات');
    d.innerHTML = '<header><h2 id="dTitle">سلة المشتريات</h2><button class="x" id="dClose" aria-label="إغلاق">✕</button></header><div class="dbody" id="dBody"></div><div class="dfoot" id="dFoot"></div>';
    document.body.append(ov, d);
    ov.addEventListener('click', closeAll);
    $('#dClose').addEventListener('click', closeAll);
    d.addEventListener('click', onDrawerClick);
    d.addEventListener('input', (e) => { const n = e.target.dataset && e.target.dataset.f; if (n) form[n] = e.target.value; });
    d.addEventListener('submit', (e) => { e.preventDefault(); submit(); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeAll(); });
  }
  function closeAll() {
    ['#cartDrawer', '#overlay', '#sideNav'].forEach((s) => { const n = $(s); if (n) n.hidden = true; });
  }
  async function openCart() {
    ensureDrawer();
    if (view === 'done' && !lastOrder) view = 'cart';
    if (view !== 'done') { view = 'cart'; formErr = null; }
    $('#cartDrawer').hidden = false; $('#overlay').hidden = false;
    render();
    if (view === 'cart') syncCart();
  }
  async function syncCart() {
    const ids = items().map((i) => i.id);
    if (!ids.length) return;
    try {
      const data = await api('/api/products?limit=48&ids=' + ids.join(','));
      const live = new Map(data.items.map((p) => [p.id, p]));
      let changed = false;
      for (const i of items()) {
        const p = live.get(i.id);
        if (!p || p.stock < 1) { delete cart[i.id]; changed = true; continue; }
        if (p.price !== i.price || p.stock !== i.stock || p.name !== i.name) changed = true;
        Object.assign(cart[i.id], { price: p.price, oldPrice: p.oldPrice, stock: p.stock, name: p.name, imageUrl: p.imageUrl });
        if (cart[i.id].qty > p.stock) cart[i.id].qty = p.stock;
      }
      if (changed) { notice = 'تم تحديث الأسعار أو الكميات المتاحة في سلتك.'; persist(); if (view === 'cart') render(); }
    } catch (_) { /* نعرض ما لدينا؛ الخادم سيتحقق عند الطلب */ }
  }
  function totals() {
    let sub = 0, tot = 0;
    for (const i of items()) { sub += (i.oldPrice && i.oldPrice > i.price ? i.oldPrice : i.price) * i.qty; tot += i.price * i.qty; }
    return { sub, tot, dis: sub - tot };
  }
  function totalsHtml(t) {
    return (t.dis > 0 ? '<div class="sum"><span>قبل الخصم</span><span>' + money(t.sub) + '</span></div><div class="sum dis"><span>الخصم</span><span>- ' + money(t.dis) + '</span></div>' : '') + '<div class="sum tot"><span>الإجمالي</span><span>' + money(t.tot) + '</span></div>';
  }
  function render() {
    const body = $('#dBody'), foot = $('#dFoot'), title = $('#dTitle');
    if (!body) return;
    const list = items(), t = totals();
    if (view === 'done' && lastOrder) {
      title.textContent = 'تم حفظ الطلب';
      body.innerHTML = '<div class="done"><div class="big">✓</div><h3>تم حفظ طلبك رقم #' + esc(lastOrder.id) + '</h3>' +
        '<div class="msg info">الطلب محفوظ في نظامنا لكنه <b>لم يصل للصيدلية بعد</b>. اضغط الزر أدناه لفتح واتساب ثم اضغط «إرسال» لإتمام الإرسال. تأكيد الصيدلية للطلب يتم بشكل منفصل بعد مراجعته.</div></div>';
      foot.innerHTML = '<a class="btn gold block" target="_blank" rel="noopener" href="' + esc(waLink(orderMessage(lastOrder))) + '">فتح واتساب وإرسال الطلب</a><button class="btn ghost block" style="margin-top:8px" data-act="close">إغلاق</button>';
      return;
    }
    if (!list.length) {
      title.textContent = 'سلة المشتريات';
      body.innerHTML = '<div class="state">سلتك فارغة حاليًا.<br>تصفّح المنتجات وأضف ما تحتاجه.</div>';
      foot.innerHTML = '<button class="btn block" data-act="close">متابعة التسوق</button>';
      return;
    }
    if (view === 'checkout') {
      title.textContent = 'إتمام الطلب';
      const fe = (k) => (formErr && formErr.fields && formErr.fields[k] ? '<div class="err">' + esc(formErr.fields[k]) + '</div>' : '');
      body.innerHTML = '<form id="coForm" novalidate><div class="review">' + list.map((i) => '<div><span>' + esc(i.name) + ' × ' + i.qty + '</span><span>' + money(i.price * i.qty) + '</span></div>').join('') + '</div>' + totalsHtml(t) +
        (formErr ? '<div class="msg err" role="alert">' + esc(formErr.message) + '</div>' : '') +
        '<div class="field"><label for="fName">الاسم</label><input id="fName" data-f="name" type="text" autocomplete="name" maxlength="100" value="' + esc(form.name) + '">' + fe('customerName') + '</div>' +
        '<div class="field"><label for="fPhone">رقم الهاتف</label><input id="fPhone" data-f="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="01XXXXXXXXX" maxlength="20" value="' + esc(form.phone) + '">' + fe('customerPhone') + '</div>' +
        '<div class="field"><label for="fAddr">العنوان بالتفصيل</label><textarea id="fAddr" data-f="address" rows="3" maxlength="500" autocomplete="street-address">' + esc(form.address) + '</textarea>' + fe('customerAddress') + '</div>' +
        '<div class="msg info">سيتم حفظ الطلب أولًا، ثم يُفتح واتساب برسالة جاهزة تحتاج منك الضغط على «إرسال».</div><button type="submit" class="btn gold block" id="saveBtn"' + (busy ? ' disabled' : '') + '>' + (busy ? 'جارٍ حفظ الطلب…' : 'حفظ الطلب') + '</button>' +
        '<button type="button" class="btn ghost block" style="margin-top:8px" data-act="back">رجوع للسلة</button></form>';
      foot.innerHTML = '';
      return;
    }
    title.textContent = 'سلة المشتريات';
    body.innerHTML = (notice ? '<div class="msg info">' + esc(notice) + '</div>' : '') + list.map((i) =>
      '<div class="citem"><img src="' + img(i.imageUrl) + '" alt="" loading="lazy"><div><h4>' + esc(i.name) + '</h4><div class="price"><b>' + money(i.price) + '</b>' + (i.oldPrice && i.oldPrice > i.price ? '<s>' + money(i.oldPrice) + '</s>' : '') + '</div>' +
      '<div class="meta"><div class="qty"><button data-act="dec" data-id="' + i.id + '" aria-label="تقليل">−</button><span>' + i.qty + '</span><button data-act="inc" data-id="' + i.id + '" aria-label="زيادة">+</button></div><button class="rm" data-act="rm" data-id="' + i.id + '">حذف</button></div>' +
      (i.qty >= i.stock ? '<div class="stock-low">وصلت للحد الأقصى المتاح (' + i.stock + ')</div>' : '') + '</div></div>').join('');
    foot.innerHTML = totalsHtml(t) + '<button class="btn gold block" style="margin-top:8px" data-act="checkout">إتمام الطلب</button>';
  }
  function onDrawerClick(e) {
    const b = e.target.closest('[data-act]'); if (!b) return;
    const id = b.dataset.id, act = b.dataset.act, it = cart[id];
    if (act === 'close') return closeAll();
    if (act === 'back') { view = 'cart'; formErr = null; return render(); }
    if (act === 'checkout') { notice = ''; view = 'checkout'; formErr = null; return render(); }
    if (!it) return;
    if (act === 'inc') { if (it.qty < it.stock) it.qty++; else toast('الكمية المتاحة فقط ' + it.stock); }
    if (act === 'dec') { if (it.qty > 1) it.qty--; else delete cart[id]; }
    if (act === 'rm') delete cart[id];
    persist(); render();
  }
  async function submit() {
    if (busy) return;
    const list = items(); if (!list.length) return;
    const orderItems = list.map((i) => ({ productId: i.id, quantity: i.qty }));
    const sig = JSON.stringify([orderItems, form.name, form.phone, form.address]);
    if (sig !== pendingSig) { pendingSig = sig; pendingKey = rid(); } // نفس المفتاح عند إعادة المحاولة بنفس البيانات
    busy = true; formErr = null; render();
    try {
      const data = await api('/api/orders', { method: 'POST', body: { customerName: form.name, customerPhone: form.phone, customerAddress: form.address, items: orderItems, idempotencyKey: pendingKey } });
      lastOrder = data.order; cart = {}; persist(); view = 'done'; busy = false; pendingKey = pendingSig = null; render();
      const w = window.open(waLink(orderMessage(lastOrder)), '_blank', 'noopener'); // قد يمنعه المتصفح؛ الزر موجود كبديل
      void w;
    } catch (err) {
      busy = false;
      let msg = err.message;
      if (err.details && err.details.length) msg += ' — ' + err.details.map((d) => (d.name || 'منتج') + ' (المتاح: ' + d.available + ')').join('، ');
      formErr = { message: msg, fields: err.fields };
      render();
      if (err.status === 409) syncCart();
    }
  }

  async function init() {
    persist();
    $('#cartBtn') && $('#cartBtn').addEventListener('click', openCart);
    const nav = $('#sideNav');
    $('#menuBtn') && $('#menuBtn').addEventListener('click', () => { ensureDrawer(); nav.hidden = false; $('#overlay').hidden = false; });
    $('#closeNav') && $('#closeNav').addEventListener('click', closeAll);
    const sf = $('#searchForm');
    if (sf) {
      const q = new URLSearchParams(location.search).get('q'); if (q) $('#searchInput').value = q;
      sf.addEventListener('submit', (e) => { e.preventDefault(); const v = $('#searchInput').value.trim(); location.href = v ? '/?q=' + encodeURIComponent(v) : '/'; });
    }
    try { config = await api('/api/config'); } catch (_) { /* default */ }
    const wa = waLink('السلام عليكم، أريد الاستفسار عن منتجات ' + config.storeName);
    ['#waFloat', '#navWa'].forEach((s) => { const a = $(s); if (a) { a.href = wa; a.target = '_blank'; a.rel = 'noopener'; } });
    try {
      const c = await api('/api/categories');
      window.MSA.categories = c.items;
      if ($('#navLinks')) $('#navLinks').innerHTML = c.items.map((x) => '<a href="/?category=' + encodeURIComponent(x.slug) + '">' + esc(x.name) + ' <small>' + x.count + '</small></a>').join('');
      document.dispatchEvent(new CustomEvent('msa:categories', { detail: c.items }));
    } catch (_) { /* nav stays empty */ }
  }

  function card(p) {
    const out = p.stock < 1;
    return '<article class="card"><a class="img" href="/product.html?id=' + p.id + '"><img src="' + img(p.imageUrl) + '" alt="' + esc(p.name) + '" loading="lazy">' +
      (p.discountPercent ? '<span class="tag">خصم ' + p.discountPercent + '%</span>' : '') + (p.isSample ? '<span class="tag sample">تجريبي</span>' : '') + '</a>' +
      '<div class="body"><h3><a href="/product.html?id=' + p.id + '">' + esc(p.name) + '</a></h3><div class="price"><b>' + money(p.price) + '</b>' + (p.oldPrice && p.oldPrice > p.price ? '<s>' + money(p.oldPrice) + '</s>' : '') + '</div>' +
      (!out && p.stock <= 5 ? '<div class="stock-low">متبقي ' + p.stock + ' فقط</div>' : '') +
      '<button class="btn" data-add="' + p.id + '"' + (out ? ' disabled' : '') + '>' + (out ? 'نفدت الكمية' : 'أضف للسلة') + '</button></div></article>';
  }

  window.MSA = { $, esc, money, api, toast, card, addToCart, openCart, img, categories: [] };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
