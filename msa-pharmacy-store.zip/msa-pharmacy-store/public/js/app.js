(function () {
  'use strict';
  const { $, esc, api, card, addToCart } = window.MSA;
  const params = new URLSearchParams(location.search);
  const st = { q: params.get('q') || '', category: params.get('category') || '', offer: params.get('offer') === '1', sort: 'new', page: 1, loading: false };
  const known = new Map(); // id -> product (لزر الإضافة)
  let sampleSeen = false;

  const qs = (extra) => {
    const p = new URLSearchParams({ limit: '12', sort: st.sort, page: String(st.page), ...extra });
    if (st.q) p.set('q', st.q);
    if (st.category) p.set('category', st.category);
    if (st.offer) p.set('offer', '1');
    return p.toString();
  };
  const remember = (items) => items.forEach((p) => { known.set(p.id, p); if (p.isSample) sampleSeen = true; });
  const showSample = () => { $('#sampleNotice').hidden = !sampleSeen; };

  function skeleton() { $('#grid').innerHTML = '<div class="skel"></div>'.repeat(4); }

  async function load(reset) {
    if (st.loading) return;
    st.loading = true;
    if (reset) { st.page = 1; skeleton(); $('#state').innerHTML = ''; $('#moreBtn').hidden = true; }
    try {
      const data = await api('/api/products?' + qs());
      remember(data.items);
      const html = data.items.map(card).join('');
      $('#grid').innerHTML = reset ? html : $('#grid').innerHTML + html;
      $('#state').innerHTML = data.total === 0 ? '<p>لا توجد منتجات مطابقة. جرّب كلمة بحث أخرى أو قسمًا مختلفًا.</p><a class="btn ghost" href="/">عرض كل المنتجات</a>' : '';
      $('#moreBtn').hidden = data.page >= data.pages;
      showSample();
    } catch (e) {
      $('#grid').innerHTML = '';
      $('#state').innerHTML = '<p>' + esc(e.message) + '</p><button class="btn" id="retry">إعادة المحاولة</button>';
      const r = $('#retry'); if (r) r.addEventListener('click', () => load(true));
    } finally { st.loading = false; }
  }

  function title() {
    const cats = window.MSA.categories || [];
    const c = cats.find((x) => x.slug === st.category);
    $('#listTitle').textContent = st.q ? 'نتائج البحث عن «' + st.q + '»' : st.offer ? 'العروض والخصومات' : c ? c.name : 'كل المنتجات';
  }

  function chips(cats) {
    const mk = (label, href, on) => '<a class="chip' + (on ? ' on' : '') + '" href="' + href + '">' + esc(label) + '</a>';
    $('#chips').innerHTML = mk('الكل', '/', !st.category && !st.offer && !st.q) + mk('العروض', '/?offer=1', st.offer) +
      cats.map((c) => mk(c.name, '/?category=' + encodeURIComponent(c.slug), c.slug === st.category)).join('');
    title();
  }

  async function loadOffers() {
    if (st.q || st.category || st.offer) return;
    try {
      const data = await api('/api/products?offer=1&limit=4');
      if (!data.items.length) return;
      remember(data.items);
      $('#offersGrid').innerHTML = data.items.map(card).join('');
      $('#offersSection').hidden = false; showSample();
    } catch (_) { /* العروض اختيارية */ }
  }

  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-add]'); if (!b) return;
    addToCart(known.get(Number(b.dataset.add)), 1);
  });
  $('#sortSel').addEventListener('change', (e) => { st.sort = e.target.value; load(true); });
  $('#moreBtn').addEventListener('click', () => { st.page++; load(false); });
  document.addEventListener('msa:categories', (e) => chips(e.detail));
  chips(window.MSA.categories || []);
  title();
  load(true);
  loadOffers();
})();
