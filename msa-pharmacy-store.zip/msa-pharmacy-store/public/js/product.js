(function () {
  'use strict';
  const { $, esc, api, money, card, addToCart, img } = window.MSA;
  const id = new URLSearchParams(location.search).get('id');
  let product = null, qty = 1;
  const rel = new Map();

  function show(p) {
    product = p;
    document.title = p.name + ' | صيدليات محمد سعد';
    const out = p.stock < 1;
    const cat = (window.MSA.categories || []).find((c) => c.slug === p.category);
    $('#pState').hidden = true;
    $('#pView').innerHTML = '<div class="crumbs"><a href="/">الرئيسية</a> / ' + (cat ? '<a href="/?category=' + encodeURIComponent(cat.slug) + '">' + esc(cat.name) + '</a> / ' : '') + esc(p.name) + '</div>' +
      '<div class="pview"><div class="gal"><img src="' + img(p.imageUrl) + '" alt="' + esc(p.name) + '">' + (p.discountPercent ? '<span class="tag">خصم ' + p.discountPercent + '%</span>' : '') + '</div><div>' +
      '<h1>' + esc(p.name) + '</h1>' + (p.subcategory ? '<div class="hint" style="color:#667085">' + esc(p.subcategory) + '</div>' : '') +
      '<div class="price"><b>' + money(p.price) + '</b>' + (p.oldPrice && p.oldPrice > p.price ? '<s>' + money(p.oldPrice) + '</s>' : '') + '</div>' +
      (p.isSample ? '<div class="msg info">منتج تجريبي: البيانات للتجربة فقط وليست بالضرورة متوفرة.</div>' : '') +
      '<p class="desc">' + esc(p.description || 'لا يوجد وصف متاح لهذا المنتج.') + '</p>' +
      '<div>' + (out ? '<span class="stock-low">نفدت الكمية</span>' : p.stock <= 5 ? '<span class="stock-low">متبقي ' + p.stock + ' فقط</span>' : '<span style="color:#667085">متوفر</span>') + '</div>' +
      '<div class="row"><div class="qty"><button id="qDec" aria-label="تقليل">−</button><span id="qVal">1</span><button id="qInc" aria-label="زيادة">+</button></div>' +
      '<button class="btn gold" id="addBtn"' + (out ? ' disabled' : '') + '>أضف للسلة</button><button class="btn ghost" id="cartGo">عرض السلة</button></div></div></div>';
    $('#qDec').addEventListener('click', () => { if (qty > 1) { qty--; $('#qVal').textContent = qty; } });
    $('#qInc').addEventListener('click', () => { if (qty < p.stock) { qty++; $('#qVal').textContent = qty; } else window.MSA.toast('الكمية المتاحة فقط ' + p.stock); });
    $('#addBtn').addEventListener('click', () => addToCart(product, qty));
    $('#cartGo').addEventListener('click', window.MSA.openCart);
  }

  async function related(p) {
    try {
      const d = await api('/api/products?limit=5&category=' + encodeURIComponent(p.category));
      const list = d.items.filter((x) => x.id !== p.id).slice(0, 4);
      if (!list.length) return;
      list.forEach((x) => rel.set(x.id, x));
      $('#relGrid').innerHTML = list.map(card).join('');
      $('#relSection').hidden = false;
    } catch (_) { /* اختياري */ }
  }

  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-add]'); if (!b) return;
    addToCart(rel.get(Number(b.dataset.add)), 1);
  });

  (async function () {
    if (!id || !/^\d+$/.test(id)) { $('#pState').innerHTML = '<p>رابط المنتج غير صحيح.</p><a class="btn" href="/">العودة للمتجر</a>'; return; }
    try {
      const d = await api('/api/products/' + id);
      show(d.product); related(d.product);
    } catch (e) {
      $('#pState').innerHTML = '<p>' + esc(e.status === 404 ? 'المنتج غير موجود أو غير متاح حاليًا.' : e.message) + '</p><a class="btn" href="/">العودة للمتجر</a>';
    }
  })();
})();
