(function () {
  'use strict';
  const $ = (s, r) => (r || document).querySelector(s);
  const esc = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = (n) => Number(n).toLocaleString('ar-EG', { maximumFractionDigits: 2 }) + ' ج.م';
  const when = (d) => new Date(d).toLocaleString('ar-EG', { timeZone: 'Africa/Cairo', dateStyle: 'medium', timeStyle: 'short' });
  const STATUS = { new: 'جديد', processing: 'قيد التجهيز', delivered: 'تم التسليم', cancelled: 'ملغي' };
  const pill = (s) => '<span class="pill ' + esc(s) + '">' + esc(STATUS[s] || s) + '</span>';
  let tab = 'dash', cats = [];
  const ostate = { q: '', status: '', from: '', to: '', page: 1 };
  const pstate = { q: '', category: '' };

  async function call(path, method, body) {
    let res;
    try {
      res = await fetch('/api/admin' + path, { method: method || 'GET', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'msa-admin' }, body: body ? JSON.stringify(body) : undefined });
    } catch (_) { throw new Error('تعذر الاتصال بالخادم'); }
    let d = null; try { d = await res.json(); } catch (_) { /* empty */ }
    if (res.status === 401 && path !== '/login' && path !== '/me') { showLogin(); throw new Error('انتهت الجلسة. سجّل الدخول من جديد.'); }
    if (!res.ok) {
      const e = new Error((d && d.error && d.error.message) || 'حدث خطأ');
      e.fields = d && d.error && d.error.fields;
      throw e;
    }
    return d;
  }
  const errText = (e) => esc(e.message) + (e.fields ? ': ' + Object.values(e.fields).map(esc).join('، ') : '');

  function showLogin() { $('#appView').hidden = true; $('#loginView').hidden = false; }
  function showApp(u) { $('#loginView').hidden = true; $('#appView').hidden = false; $('#who').textContent = u; go(tab); }

  $('#loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const m = $('#loginMsg'); m.innerHTML = '';
    try {
      const d = await call('/login', 'POST', { username: $('#lu').value, password: $('#lp').value });
      $('#lp').value = ''; showApp(d.username);
    } catch (err) { m.innerHTML = '<div class="msg err">' + esc(err.message) + '</div>'; }
  });
  $('#logoutBtn').addEventListener('click', async () => { try { await call('/logout', 'POST', {}); } catch (_) { /* ignore */ } showLogin(); });
  $('#tabs').addEventListener('click', (e) => { const b = e.target.closest('[data-tab]'); if (b) go(b.dataset.tab); });

  async function go(t) {
    tab = t;
    document.querySelectorAll('#tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === t));
    const v = $('#view'); v.innerHTML = '<p>جارٍ التحميل…</p>';
    try {
      if (!cats.length || t === 'cats') cats = (await (await fetch('/api/categories')).json()).items || [];
      await ({ dash: dash, orders: orders, products: products, cats: categories, account: account })[t](v);
    } catch (e) { v.innerHTML = '<div class="msg err">' + errText(e) + '</div>'; }
  }

  async function dash(v) {
    const s = await call('/stats');
    v.innerHTML = '<div class="cards"><div class="stat"><b>' + s.newOrders + '</b><span>طلبات جديدة</span></div><div class="stat"><b>' + s.totalOrders + '</b><span>إجمالي الطلبات</span></div>' +
      '<div class="stat"><b>' + money(s.sales) + '</b><span>مبيعات (غير الملغاة)</span></div><div class="stat"><b>' + s.products + '</b><span>المنتجات</span></div><div class="stat"><b>' + s.lowStock + '</b><span>مخزون منخفض (5 أو أقل)</span></div></div>' +
      '<div class="panel"><button class="btn" id="goNew">عرض الطلبات الجديدة</button></div>';
    $('#goNew').addEventListener('click', () => { ostate.status = 'new'; ostate.page = 1; go('orders'); });
  }

  // ---------- الطلبات ----------
  async function orders(v) {
    v.innerHTML = '<div class="panel"><div class="tools"><div><label class="hint">بحث (اسم/هاتف/رقم طلب)</label><input id="oq" value="' + esc(ostate.q) + '"></div>' +
      '<div><label class="hint">الحالة</label><select id="os"><option value="">كل الحالات</option>' + Object.keys(STATUS).map((k) => '<option value="' + k + '"' + (ostate.status === k ? ' selected' : '') + '>' + STATUS[k] + '</option>').join('') + '</select></div>' +
      '<div><label class="hint">من تاريخ</label><input id="of" type="date" value="' + esc(ostate.from) + '"></div><div><label class="hint">إلى تاريخ</label><input id="ot" type="date" value="' + esc(ostate.to) + '"></div>' +
      '<button class="btn" id="ogo">بحث</button></div><div id="olist">جارٍ التحميل…</div></div>';
    const apply = () => { ostate.q = $('#oq').value.trim(); ostate.status = $('#os').value; ostate.from = $('#of').value; ostate.to = $('#ot').value; ostate.page = 1; loadOrders(); };
    $('#ogo').addEventListener('click', apply);
    $('#oq').addEventListener('keydown', (e) => { if (e.key === 'Enter') apply(); });
    await loadOrders();
  }
  async function loadOrders() {
    const box = $('#olist');
    try {
      const p = new URLSearchParams({ page: ostate.page });
      ['q', 'status', 'from', 'to'].forEach((k) => { if (ostate[k]) p.set(k, ostate[k]); });
      const d = await call('/orders?' + p);
      box.innerHTML = d.items.length ? '<div class="tw"><table><thead><tr><th>#</th><th>التاريخ</th><th>العميل</th><th>الهاتف</th><th>المنتجات</th><th>الإجمالي</th><th>الحالة</th><th></th></tr></thead><tbody>' +
        d.items.map((o) => '<tr><td>' + o.id + '</td><td>' + esc(when(o.createdAt)) + '</td><td>' + esc(o.customerName) + '</td><td>' + esc(o.customerPhone) + '</td><td>' + o.itemCount + '</td><td>' + money(o.total) + '</td><td>' + pill(o.status) + '</td><td><button class="btn sm" data-order="' + o.id + '">تفاصيل</button></td></tr>').join('') +
        '</tbody></table></div><div class="pg"><button class="btn sm ghost" id="pp"' + (d.page <= 1 ? ' disabled' : '') + '>السابق</button><span>صفحة ' + d.page + ' من ' + d.pages + ' (' + d.total + ' طلب)</span><button class="btn sm ghost" id="pn"' + (d.page >= d.pages ? ' disabled' : '') + '>التالي</button></div>' : '<p>لا توجد طلبات مطابقة.</p>';
      box.querySelectorAll('[data-order]').forEach((b) => b.addEventListener('click', () => orderDialog(b.dataset.order)));
      const pp = $('#pp'), pn = $('#pn');
      if (pp) pp.addEventListener('click', () => { ostate.page--; loadOrders(); });
      if (pn) pn.addEventListener('click', () => { ostate.page++; loadOrders(); });
    } catch (e) { box.innerHTML = '<div class="msg err">' + errText(e) + '</div>'; }
  }
  async function orderDialog(id) {
    const dlg = $('#dlg');
    try {
      const { order: o } = await call('/orders/' + id);
      dlg.innerHTML = '<div class="dlg"><h2>طلب #' + o.id + ' ' + pill(o.status) + '</h2><p class="hint">' + esc(when(o.createdAt)) + '</p>' +
        '<p><b>' + esc(o.customerName) + '</b><br>الهاتف: <a href="tel:' + esc(o.customerPhone) + '">' + esc(o.customerPhone) + '</a><br>العنوان: ' + esc(o.customerAddress) + '</p>' +
        '<div class="tw"><table><thead><tr><th>المنتج</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr></thead><tbody>' + o.items.map((i) => '<tr><td>' + esc(i.name) + '</td><td>' + i.quantity + '</td><td>' + money(i.unitPrice) + '</td><td>' + money(i.lineTotal) + '</td></tr>').join('') + '</tbody></table></div>' +
        '<p>قبل الخصم: ' + money(o.subtotal) + ' — الخصم: ' + money(o.discount) + '<br><b>الإجمالي: ' + money(o.total) + '</b></p>' +
        '<div class="field"><label>تغيير الحالة</label><select id="ns">' + Object.keys(STATUS).map((k) => '<option value="' + k + '"' + (o.status === k ? ' selected' : '') + '>' + STATUS[k] + '</option>').join('') + '</select><div class="hint">الإلغاء يُرجع الكميات للمخزون ولا يمكن التراجع عنه.</div></div><div id="dm"></div>' +
        '<div class="dfoot"><button class="btn ghost" id="dc">إغلاق</button><button class="btn" id="ds">حفظ الحالة</button></div></div>';
      dlg.showModal();
      $('#dc').addEventListener('click', () => dlg.close());
      $('#ds').addEventListener('click', async () => {
        const st = $('#ns').value;
        if (st === 'cancelled' && o.status !== 'cancelled' && !confirm('تأكيد إلغاء الطلب وإرجاع المخزون؟')) return;
        try { await call('/orders/' + id + '/status', 'PATCH', { status: st }); dlg.close(); loadOrders(); }
        catch (e) { $('#dm').innerHTML = '<div class="msg err">' + errText(e) + '</div>'; }
      });
    } catch (e) { alert(e.message); }
  }

  // ---------- المنتجات ----------
  async function products(v) {
    v.innerHTML = '<div class="panel"><div class="tools"><div><label class="hint">بحث</label><input id="pq" value="' + esc(pstate.q) + '"></div><div><label class="hint">القسم</label><select id="pc"><option value="">كل الأقسام</option>' +
      cats.map((c) => '<option value="' + esc(c.slug) + '"' + (pstate.category === c.slug ? ' selected' : '') + '>' + esc(c.name) + '</option>').join('') + '</select></div><button class="btn" id="pgo">بحث</button><button class="btn gold" id="padd">+ إضافة منتج</button></div><div id="plist">جارٍ التحميل…</div></div>';
    $('#pgo').addEventListener('click', () => { pstate.q = $('#pq').value.trim(); pstate.category = $('#pc').value; loadProducts(); });
    $('#pq').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('#pgo').click(); });
    $('#padd').addEventListener('click', () => productDialog(null));
    await loadProducts();
  }
  let plist = [];
  async function loadProducts() {
    const box = $('#plist');
    try {
      const p = new URLSearchParams(); if (pstate.q) p.set('q', pstate.q); if (pstate.category) p.set('category', pstate.category);
      plist = (await call('/products?' + p)).items;
      const cname = (s) => (cats.find((c) => c.slug === s) || {}).name || s;
      box.innerHTML = plist.length ? '<div class="tw"><table><thead><tr><th>#</th><th>المنتج</th><th>القسم</th><th>السعر</th><th>المخزون</th><th>ظاهر</th><th>عرض</th><th></th></tr></thead><tbody>' +
        plist.map((x) => '<tr data-id="' + x.id + '"><td>' + x.id + '</td><td>' + esc(x.name) + (x.isSample ? ' <span class="pill">تجريبي</span>' : '') + '</td><td>' + esc(cname(x.category)) + '</td><td>' + money(x.price) + (x.oldPrice ? '<br><s class="hint">' + money(x.oldPrice) + '</s> (' + x.discountPercent + '%)' : '') + '</td>' +
          '<td><input type="number" min="0" max="100000" value="' + x.stock + '" data-stock="' + x.id + '"> <button class="btn sm ghost" data-savestock="' + x.id + '">حفظ</button></td>' +
          '<td><input type="checkbox" data-tg="isActive" ' + (x.isActive ? 'checked' : '') + ' aria-label="ظاهر"></td><td><input type="checkbox" data-tg="isOffer" ' + (x.isOffer ? 'checked' : '') + ' aria-label="عرض"></td>' +
          '<td><button class="btn sm" data-edit="' + x.id + '">تعديل</button> <button class="btn sm danger" data-del="' + x.id + '">حذف</button></td></tr>').join('') + '</tbody></table></div>' : '<p>لا توجد منتجات.</p>';
      box.onclick = async (e) => {
        const b = e.target.closest('button'); if (!b) return;
        try {
          if (b.dataset.edit) productDialog(plist.find((x) => x.id === Number(b.dataset.edit)));
          else if (b.dataset.savestock) {
            await call('/products/' + b.dataset.savestock, 'PATCH', { stock: Number(box.querySelector('[data-stock="' + b.dataset.savestock + '"]').value) });
            b.textContent = 'تم ✓'; setTimeout(() => { b.textContent = 'حفظ'; }, 1200);
          } else if (b.dataset.del) {
            const x = plist.find((y) => y.id === Number(b.dataset.del));
            if (confirm('هل أنت متأكد من حذف «' + x.name + '»؟ لا يمكن التراجع. (سجلات الطلبات القديمة تبقى محفوظة)')) { await call('/products/' + x.id, 'DELETE'); loadProducts(); }
          }
        } catch (err) { alert(err.message + (err.fields ? '\n' + Object.values(err.fields).join('\n') : '')); }
      };
      box.onchange = async (e) => {
        const t = e.target; if (!t.dataset.tg) return;
        const id = t.closest('tr').dataset.id;
        try { await call('/products/' + id, 'PATCH', { [t.dataset.tg]: t.checked }); } catch (err) { t.checked = !t.checked; alert(err.message); }
      };
    } catch (e) { box.innerHTML = '<div class="msg err">' + errText(e) + '</div>'; }
  }
  function productDialog(p) {
    const dlg = $('#dlg'); const x = p || { name: '', description: '', price: '', oldPrice: '', imageUrl: '', category: cats[0] ? cats[0].slug : '', subcategory: '', stock: 0, isOffer: false, isActive: true };
    dlg.innerHTML = '<form id="pf" novalidate><h2>' + (p ? 'تعديل منتج #' + p.id : 'إضافة منتج') + '</h2><div class="msg">تنبيه: ممنوع إضافة الأدوية إلى المتجر.</div>' +
      '<div class="field"><label>اسم المنتج</label><input name="name" maxlength="200" value="' + esc(x.name) + '"></div>' +
      '<div class="two"><div class="field"><label>القسم</label><select name="category">' + cats.map((c) => '<option value="' + esc(c.slug) + '"' + (x.category === c.slug ? ' selected' : '') + '>' + esc(c.name) + '</option>').join('') + '</select></div><div class="field"><label>قسم فرعي (اختياري)</label><input name="subcategory" maxlength="100" value="' + esc(x.subcategory || '') + '"></div></div>' +
      '<div class="two"><div class="field"><label>السعر الحالي (ج.م)</label><input name="price" inputmode="decimal" value="' + esc(x.price) + '"></div><div class="field"><label>السعر قبل الخصم (اختياري)</label><input name="oldPrice" inputmode="decimal" value="' + esc(x.oldPrice == null ? '' : x.oldPrice) + '"></div></div>' +
      '<div class="two"><div class="field"><label>الكمية في المخزون</label><input name="stock" type="number" min="0" max="100000" value="' + esc(x.stock) + '"></div><div class="field"><label>رابط الصورة (اختياري)</label><input name="imageUrl" type="url" placeholder="https://..." value="' + esc(x.imageUrl || '') + '"></div></div>' +
      '<div class="field"><label>الوصف</label><textarea name="description" rows="4" maxlength="4000">' + esc(x.description) + '</textarea></div>' +
      '<div class="chk"><label><input type="checkbox" name="isActive" ' + (x.isActive ? 'checked' : '') + '> ظاهر في المتجر</label><label><input type="checkbox" name="isOffer" ' + (x.isOffer ? 'checked' : '') + '> ضمن العروض</label></div><div id="pm"></div>' +
      '<div class="dfoot"><button type="button" class="btn ghost" id="pcx">إلغاء</button><button class="btn">حفظ</button></div></form>';
    dlg.showModal();
    $('#pcx').addEventListener('click', () => dlg.close());
    $('#pf').addEventListener('submit', async (e) => {
      e.preventDefault();
      const f = e.target.elements;
      const body = { name: f.name.value, category: f.category.value, subcategory: f.subcategory.value.trim() || null, price: f.price.value, oldPrice: f.oldPrice.value.trim() || null, stock: Number(f.stock.value), imageUrl: f.imageUrl.value.trim() || null, description: f.description.value, isActive: f.isActive.checked, isOffer: f.isOffer.checked };
      try { await call(p ? '/products/' + p.id : '/products', p ? 'PATCH' : 'POST', body); dlg.close(); loadProducts(); }
      catch (err) { $('#pm').innerHTML = '<div class="msg err">' + errText(err) + '</div>'; }
    });
  }

  // ---------- الأقسام ----------
  async function categories(v) {
    v.innerHTML = '<div class="panel"><h3>الأقسام</h3><div class="tw"><table><thead><tr><th>المعرّف</th><th>الاسم</th><th>الترتيب</th></tr></thead><tbody>' + cats.map((c) => '<tr><td>' + esc(c.slug) + '</td><td>' + esc(c.name) + '</td><td>' + esc(c.sortOrder == null ? '' : c.sortOrder) + '</td></tr>').join('') + '</tbody></table></div></div>' +
      '<div class="panel"><h3>إضافة قسم</h3><form id="cf" class="tools"><div><label class="hint">المعرّف (إنجليزي صغير، مثل baby-care)</label><input name="slug" required></div><div><label class="hint">اسم القسم</label><input name="name" required></div><div><label class="hint">الترتيب</label><input name="sortOrder" type="number" value="10"></div><button class="btn">إضافة</button></form><div id="cm"></div></div>';
    $('#cf').addEventListener('submit', async (e) => {
      e.preventDefault(); const f = e.target.elements;
      try { await call('/categories', 'POST', { slug: f.slug.value.trim(), name: f.name.value.trim(), sortOrder: f.sortOrder.value }); cats = []; go('cats'); }
      catch (err) { $('#cm').innerHTML = '<div class="msg err">' + errText(err) + '</div>'; }
    });
  }

  // ---------- الحساب ----------
  function account(v) {
    v.innerHTML = '<div class="panel" style="max-width:420px"><h3>تغيير كلمة المرور</h3><form id="af"><div class="field"><label>كلمة المرور الحالية</label><input name="cur" type="password" autocomplete="current-password" required></div><div class="field"><label>كلمة المرور الجديدة (10 أحرف على الأقل)</label><input name="nw" type="password" autocomplete="new-password" minlength="10" required></div><div id="am"></div><button class="btn">تغيير</button></form></div>';
    $('#af').addEventListener('submit', async (e) => {
      e.preventDefault(); const f = e.target.elements;
      try { await call('/password', 'POST', { currentPassword: f.cur.value, newPassword: f.nw.value }); e.target.reset(); $('#am').innerHTML = '<div class="msg ok">تم تغيير كلمة المرور وإنهاء الجلسات الأخرى.</div>'; }
      catch (err) { $('#am').innerHTML = '<div class="msg err">' + errText(err) + '</div>'; }
    });
  }

  (async function () {
    try { const d = await call('/me'); showApp(d.username); } catch (_) { showLogin(); }
  })();
})();
