'use strict';
// اختبارات متكاملة على قاعدة بيانات حقيقية. تُتخطى تلقائيًا إذا لم يُضبط TEST_DATABASE_URL.
// تحذير: تنشئ وتحذف بيانات؛ استخدم قاعدة/فرع Neon مخصصًا للاختبار فقط (بعد تطبيق database/schema.sql عليه).
const test = require('node:test');
const assert = require('node:assert/strict');

const DB = process.env.TEST_DATABASE_URL;

test('API integration', { skip: DB ? false : 'TEST_DATABASE_URL غير مضبوط' }, async (t) => {
  process.env.DATABASE_URL = DB;
  process.env.NODE_ENV = 'test';
  process.env.SESSION_SECRET = 'test-secret-'.repeat(4);
  const bcrypt = require('bcryptjs');
  const { createApp } = require('../src/app');
  const { pool } = require('../src/db');

  const rnd = Math.random().toString(36).slice(2, 8);
  const cat = `t-${rnd}`;
  const adminName = `t_admin_${rnd}`;
  const adminPass = `Pass-${rnd}-long-enough`;
  const server = await new Promise((r) => { const s = createApp().listen(0, () => r(s)); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const key = () => `k${Date.now()}${Math.random().toString(36).slice(2)}`.padEnd(20, 'x');

  async function call(method, path, body, cookie, admin = false) {
    const headers = { 'Content-Type': 'application/json' };
    if (cookie) headers.Cookie = cookie;
    if (admin) headers['X-Requested-With'] = 'msa-admin';
    const res = await fetch(base + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
    let json = null; try { json = await res.json(); } catch (_) { /* no body */ }
    const sc = res.headers.getSetCookie ? res.headers.getSetCookie()[0] : null;
    return { status: res.status, json, cookie: sc ? sc.split(';')[0] : null };
  }

  await pool.query('INSERT INTO categories (slug, name) VALUES ($1,$2)', [cat, `قسم اختبار ${rnd}`]);
  await pool.query('INSERT INTO admin_users (username, password_hash) VALUES ($1,$2)', [adminName, await bcrypt.hash(adminPass, 10)]);
  let cookie;
  const mkProduct = async (over = {}) => (await call('POST', '/api/admin/products', { name: `منتج ${rnd} ${Math.random().toString(36).slice(2, 6)}`, price: 100, oldPrice: 150, category: cat, stock: 5, isOffer: true, ...over }, cookie, true)).json.product;
  const order = (items, over = {}) => call('POST', '/api/orders', { customerName: 'اختبار آلي', customerPhone: '01012345678', customerAddress: 'عنوان اختبار طويل بما يكفي', idempotencyKey: key(), items, ...over });

  t.after(async () => {
    await pool.query("DELETE FROM orders WHERE customer_name = 'اختبار آلي' AND id IN (SELECT order_id FROM order_items WHERE product_name LIKE $1)", [`منتج ${rnd}%`]);
    await pool.query('DELETE FROM products WHERE category = $1', [cat]);
    await pool.query('DELETE FROM categories WHERE slug = $1', [cat]);
    await pool.query('DELETE FROM admin_users WHERE username = $1', [adminName]);
    await new Promise((r) => server.close(r));
    await pool.end();
  });

  await t.test('health والمنتجات العامة', async () => {
    assert.equal((await call('GET', '/api/health')).status, 200);
    assert.equal((await call('GET', '/api/products')).status, 200);
    assert.equal((await call('GET', '/api/categories')).status, 200);
  });

  await t.test('منع الوصول غير المصرح به للإدارة', async () => {
    assert.equal((await call('GET', '/api/admin/orders')).status, 401);
    assert.equal((await call('POST', '/api/admin/products', {}, null, true)).status, 401);
    assert.equal((await call('POST', '/api/admin/products', {})).status, 403); // بدون ترويسة CSRF
    assert.equal((await call('POST', '/api/admin/login', { username: adminName, password: 'wrong' }, null, true)).status, 401);
  });

  await t.test('تسجيل دخول المدير', async () => {
    const r = await call('POST', '/api/admin/login', { username: adminName, password: adminPass }, null, true);
    assert.equal(r.status, 200);
    cookie = r.cookie;
    assert.equal((await call('GET', '/api/admin/me', null, cookie)).status, 200);
  });

  let p;
  await t.test('إضافة وتعديل المنتج والتحقق من المدخلات', async () => {
    assert.equal((await call('POST', '/api/admin/products', { name: 'x', price: -1, category: cat }, cookie, true)).status, 400);
    assert.equal((await call('POST', '/api/admin/products', { name: 'منتج خاطئ', price: 100, category: 'no-such-cat' }, cookie, true)).status, 400);
    p = await mkProduct();
    assert.equal(p.discountPercent, 33);
    const u = await call('PATCH', `/api/admin/products/${p.id}`, { price: 90, stock: 7 }, cookie, true);
    assert.equal(u.status, 200);
    assert.equal(u.json.product.stock, 7);
  });

  await t.test('السعر القادم من المتصفح يُتجاهل', async () => {
    const r = await order([{ productId: p.id, quantity: 1, price: 0.01 }], { total: 1 });
    assert.equal(r.status, 201);
    assert.equal(r.json.order.total, 90);
    assert.equal(r.json.order.items[0].unitPrice, 90);
  });

  await t.test('منع تجاوز المخزون', async () => {
    const r = await order([{ productId: p.id, quantity: 999 }]);
    assert.equal(r.status, 409);
    assert.equal(r.json.error.code, 'STOCK_CONFLICT');
  });

  await t.test('منع الطلبات الناقصة', async () => {
    assert.equal((await order([])).status, 400);
    assert.equal((await order([{ productId: p.id, quantity: 1 }], { customerPhone: '1' })).status, 400);
  });

  await t.test('التراجع الكامل عند فشل أحد العناصر', async () => {
    const a = await mkProduct({ stock: 5 });
    const b = await mkProduct({ stock: 1 });
    const before = (await pool.query('SELECT COUNT(*)::int n FROM orders')).rows[0].n;
    const r = await order([{ productId: a.id, quantity: 2 }, { productId: b.id, quantity: 2 }]);
    assert.equal(r.status, 409);
    assert.equal((await pool.query('SELECT stock FROM products WHERE id=$1', [a.id])).rows[0].stock, 5);
    assert.equal((await pool.query('SELECT COUNT(*)::int n FROM orders')).rows[0].n, before);
  });

  await t.test('الطلبات المتزامنة: مخزون 1 ينجح لطلب واحد فقط', async () => {
    const x = await mkProduct({ stock: 1 });
    const rs = await Promise.all(Array.from({ length: 5 }, () => order([{ productId: x.id, quantity: 1 }])));
    assert.equal(rs.filter((r) => r.status === 201).length, 1);
    assert.equal(rs.filter((r) => r.status === 409).length, 4);
    assert.equal((await pool.query('SELECT stock FROM products WHERE id=$1', [x.id])).rows[0].stock, 0);
  });

  await t.test('منع تكرار الطلب بنفس المفتاح', async () => {
    const k = key();
    const before = (await pool.query('SELECT stock FROM products WHERE id=$1', [p.id])).rows[0].stock;
    const r1 = await order([{ productId: p.id, quantity: 1 }], { idempotencyKey: k });
    const r2 = await order([{ productId: p.id, quantity: 1 }], { idempotencyKey: k });
    assert.equal(r1.status, 201);
    assert.equal(r2.status, 200);
    assert.equal(r2.json.order.id, r1.json.order.id);
    assert.equal((await pool.query('SELECT stock FROM products WHERE id=$1', [p.id])).rows[0].stock, before - 1);
  });

  await t.test('الإدارة: عرض الطلبات وتغيير الحالة وإرجاع المخزون عند الإلغاء', async () => {
    const y = await mkProduct({ stock: 4 });
    const o = (await order([{ productId: y.id, quantity: 3 }])).json.order;
    assert.equal((await pool.query('SELECT stock FROM products WHERE id=$1', [y.id])).rows[0].stock, 1);
    const list = await call('GET', `/api/admin/orders?q=${o.id}&status=new`, null, cookie);
    assert.ok(list.json.items.some((i) => i.id === o.id));
    assert.equal((await call('GET', `/api/admin/orders/${o.id}`, null, cookie)).json.order.items.length, 1);
    assert.equal((await call('PATCH', `/api/admin/orders/${o.id}/status`, { status: 'bogus' }, cookie, true)).status, 400);
    assert.equal((await call('PATCH', `/api/admin/orders/${o.id}/status`, { status: 'processing' }, cookie, true)).json.order.status, 'processing');
    assert.equal((await call('PATCH', `/api/admin/orders/${o.id}/status`, { status: 'cancelled' }, cookie, true)).status, 200);
    assert.equal((await pool.query('SELECT stock FROM products WHERE id=$1', [y.id])).rows[0].stock, 4);
    assert.equal((await call('PATCH', `/api/admin/orders/${o.id}/status`, { status: 'new' }, cookie, true)).status, 409);
  });

  await t.test('حذف المنتج يحتفظ بسجل الطلبات', async () => {
    const z = await mkProduct({ stock: 2 });
    const o = (await order([{ productId: z.id, quantity: 1 }])).json.order;
    assert.equal((await call('DELETE', `/api/admin/products/${z.id}`, null, cookie, true)).status, 200);
    assert.equal((await call('GET', `/api/products/${z.id}`)).status, 404);
    const d = await call('GET', `/api/admin/orders/${o.id}`, null, cookie);
    assert.equal(d.json.order.items[0].productId, null);
    assert.equal((await call('DELETE', `/api/admin/products/${z.id}`, null, cookie, true)).status, 404);
  });

  await t.test('منتج مخفي لا يظهر ولا يُباع', async () => {
    const h = await mkProduct({ isActive: false });
    assert.equal((await call('GET', `/api/products/${h.id}`)).status, 404);
    assert.equal((await order([{ productId: h.id, quantity: 1 }])).status, 409);
  });

  await t.test('تسجيل الخروج', async () => {
    assert.equal((await call('POST', '/api/admin/logout', {}, cookie, true)).status, 200);
    assert.equal((await call('GET', '/api/admin/orders', null, cookie)).status, 401);
  });
});
