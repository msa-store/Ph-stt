'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const V = require('../src/validate');

const KEY = 'abcdefghijklmnopqrstuvwxyz012345';
const goodOrder = { customerName: 'أحمد علي', customerPhone: '01010031279', customerAddress: '12 شارع النصر، القاهرة', idempotencyKey: KEY, items: [{ productId: 1, quantity: 2 }] };

test('normalizePhone: أرقام مصرية بصيغ مختلفة', () => {
  assert.equal(V.normalizePhone('01010031279'), '01010031279');
  assert.equal(V.normalizePhone('+20 101 003 1279'), '01010031279');
  assert.equal(V.normalizePhone('201010031279'), '01010031279');
  assert.equal(V.normalizePhone('٠١٠١٠٠٣١٢٧٩'), '01010031279');
  assert.equal(V.normalizePhone('0131234567'), null);
  assert.equal(V.normalizePhone('abc'), null);
  assert.equal(V.normalizePhone(null), null);
});

test('parseMoney: قبول الصيغ الصحيحة ورفض غيرها', () => {
  assert.equal(V.parseMoney(699), 69900);
  assert.equal(V.parseMoney('699.5'), 69950);
  assert.equal(V.parseMoney('٦٩٩'), 69900);
  assert.equal(V.parseMoney('-5'), null);
  assert.equal(V.parseMoney('1.234'), null);
  assert.equal(V.parseMoney('1e5'), null);
  assert.equal(V.parseMoney(NaN), null);
  assert.equal(V.parseMoney({}), null);
});

test('validateOrder: طلب صحيح ودمج المنتجات المكررة', () => {
  const r = V.validateOrder({ ...goodOrder, items: [{ productId: 1, quantity: 2 }, { productId: '1', quantity: 1 }, { productId: 2, quantity: 1 }] });
  assert.equal(r.ok, true);
  assert.deepEqual(r.value.items, [{ productId: 1, quantity: 3 }, { productId: 2, quantity: 1 }]);
});

test('validateOrder: يتجاهل أي سعر أو إجمالي قادم من المتصفح', () => {
  const r = V.validateOrder({ ...goodOrder, total: 1, items: [{ productId: 1, quantity: 1, price: 0.01 }] });
  assert.equal(r.ok, true);
  assert.deepEqual(r.value.items, [{ productId: 1, quantity: 1 }]);
  assert.equal('total' in r.value, false);
});

test('validateOrder: يرفض الطلبات الناقصة أو غير الصالحة', () => {
  assert.equal(V.validateOrder({}).ok, false);
  assert.equal(V.validateOrder({ ...goodOrder, items: [] }).ok, false);
  assert.equal(V.validateOrder({ ...goodOrder, customerName: '' }).ok, false);
  assert.equal(V.validateOrder({ ...goodOrder, customerPhone: '123' }).ok, false);
  assert.equal(V.validateOrder({ ...goodOrder, customerAddress: 'قصير' }).ok, false);
  assert.equal(V.validateOrder({ ...goodOrder, idempotencyKey: 'x' }).ok, false);
  assert.equal(V.validateOrder({ ...goodOrder, items: [{ productId: 1, quantity: 0 }] }).ok, false);
  assert.equal(V.validateOrder({ ...goodOrder, items: [{ productId: 1, quantity: -3 }] }).ok, false);
  assert.equal(V.validateOrder({ ...goodOrder, items: [{ productId: 1, quantity: 1.5 }] }).ok, false);
  assert.equal(V.validateOrder({ ...goodOrder, items: [{ productId: 'abc', quantity: 1 }] }).ok, false);
  assert.equal(V.validateOrder(null).ok, false);
});

test('validateProduct: إنشاء صحيح وقيم افتراضية', () => {
  const r = V.validateProduct({ name: 'واقي شمس', price: 699, oldPrice: 850, category: 'skin-care' });
  assert.equal(r.ok, true);
  assert.equal(r.value.price, '699.00');
  assert.equal(r.value.old_price, '850.00');
  assert.equal(r.value.stock, 0);
  assert.equal(r.value.is_active, true);
  assert.equal(r.value.is_offer, false);
});

test('validateProduct: يرفض سعرًا قديمًا أقل من أو يساوي الحالي وروابط صور خطرة', () => {
  assert.equal(V.validateProduct({ name: 'منتج', price: 100, oldPrice: 100, category: 'skin-care' }).ok, false);
  assert.equal(V.validateProduct({ name: 'منتج', price: 100, category: 'skin-care', imageUrl: 'javascript:alert(1)' }).ok, false);
  assert.equal(V.validateProduct({ name: 'منتج', price: 100, category: 'skin-care', imageUrl: '//evil.com/x.png' }).ok, false);
  assert.equal(V.validateProduct({ name: 'منتج', price: 100, category: 'skin-care', imageUrl: 'https://cdn.example.com/x.png' }).ok, true);
  assert.equal(V.validateProduct({ name: 'منتج', price: 0, category: 'skin-care' }).ok, false);
  assert.equal(V.validateProduct({ name: 'منتج', price: 10, category: 'skin-care', stock: -1 }).ok, false);
  assert.equal(V.validateProduct({ name: 'منتج', price: 10, category: 'skin-care', isOffer: 'yes' }).ok, false);
});

test('validateProduct partial: يعدّل الحقول المرسلة فقط', () => {
  const r = V.validateProduct({ stock: 5 }, { partial: true });
  assert.equal(r.ok, true);
  assert.deepEqual(r.value, { stock: 5 });
  assert.equal(V.validateProduct({ oldPrice: null }, { partial: true }).value.old_price, null);
});

test('كلمة المرور واسم المستخدم', () => {
  assert.ok(V.validatePassword('short'));
  assert.equal(V.validatePassword('a-long-enough-pass', 'admin'), null);
  assert.ok(V.validatePassword('adminadmin', 'adminadmin'));
  assert.equal(V.validateUsername(' Admin '), 'admin');
  assert.equal(V.validateUsername('a b'), null);
});

test('validateCategory', () => {
  assert.equal(V.validateCategory({ slug: 'baby-care', name: 'العناية بالطفل' }).ok, true);
  assert.equal(V.validateCategory({ slug: 'عربي', name: 'x' }).ok, false);
});
