'use strict';
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { pool } = require('../src/db');

(async () => {
  const withSeed = process.argv.includes('--seed');
  try {
    await pool.query(fs.readFileSync(path.join(__dirname, '..', 'database', 'schema.sql'), 'utf8'));
    console.log('schema applied');
    if (withSeed) {
      await pool.query(fs.readFileSync(path.join(__dirname, '..', 'database', 'seed.sql'), 'utf8'));
      console.log('sample data applied (بيانات تجريبية)');
    }
  } catch (e) {
    console.error('failed:', e.code || e.message);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
})();
