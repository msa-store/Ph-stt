'use strict';
// يتحقق أن كل ملف CSS/JS/صورة مشار إليه في HTML موجود فعلًا، وأن كل المسارات التي تستدعيها الواجهة معرّفة في الخادم.
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
let bad = 0;
for (const html of ['public/index.html', 'public/product.html', 'public/admin/index.html']) {
  const src = fs.readFileSync(path.join(root, html), 'utf8');
  for (const m of src.matchAll(/(?:src|href)="(\/[^"#?]+\.(?:css|js|svg|png))"/g)) {
    const ok = fs.existsSync(path.join(root, 'public', m[1]));
    if (!ok) { bad++; console.log('MISSING', html, m[1]); }
  }
}
const server = fs.readFileSync(path.join(root, 'src/routes/public.js'), 'utf8') + fs.readFileSync(path.join(root, 'src/routes/admin.js'), 'utf8');
const client = ['common', 'app', 'product', 'admin'].map((f) => fs.readFileSync(path.join(root, 'public/js', f + '.js'), 'utf8')).join('\n');
const need = ['/api/config', '/api/categories', '/api/products', '/api/orders', "'/login'", "'/logout'", "'/me'", "'/stats'", "'/orders'", "'/orders/:id'", "'/orders/:id/status'", "'/products'", "'/products/:id'", "'/categories'", "'/password'"];
for (const n of need) if (!server.includes(n.replace(/^\/api/, '')) && !server.includes(n)) { bad++; console.log('ROUTE NOT FOUND', n); }
for (const n of ['/api/orders', '/api/products', '/api/categories', '/api/config', "'/orders/'", "'/products/'", "'/categories'", "'/password'", "'/stats'"]) if (!client.includes(n)) console.log('note: client does not use', n);
console.log(bad ? 'FAILED' : 'project check passed');
process.exitCode = bad ? 1 : 0;
