'use strict';
// الاستخدام: ADMIN_USERNAME=... ADMIN_PASSWORD=... npm run admin:create [-- --reset]
require('dotenv').config();
const bcrypt = require('bcryptjs');
const { pool } = require('../src/db');
const { validateUsername, validatePassword } = require('../src/validate');

(async () => {
  try {
    const username = validateUsername(process.env.ADMIN_USERNAME);
    if (!username) throw new Error('ADMIN_USERNAME غير صالح');
    const problem = validatePassword(process.env.ADMIN_PASSWORD, username);
    if (problem) throw new Error(problem);
    const hash = await bcrypt.hash(process.env.ADMIN_PASSWORD, 12);
    const reset = process.argv.includes('--reset');
    const sql = reset
      ? 'INSERT INTO admin_users (username, password_hash) VALUES ($1,$2) ON CONFLICT (username) DO UPDATE SET password_hash = EXCLUDED.password_hash'
      : 'INSERT INTO admin_users (username, password_hash) VALUES ($1,$2)';
    await pool.query(sql, [username, hash]);
    console.log(reset ? 'admin password set' : 'admin created', `(username: ${username})`);
  } catch (e) {
    console.error('failed:', e.code === '23505' ? 'المستخدم موجود (استخدم --reset لتغيير كلمة المرور)' : (e.message || e.code));
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
})();
