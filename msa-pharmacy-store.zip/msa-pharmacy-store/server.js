'use strict';
require('dotenv').config();
const { createApp } = require('./src/app');
const { pool } = require('./src/db');
const { ensureFirstAdmin } = require('./src/bootstrap');

const app = createApp();
const port = Number(process.env.PORT) || 3000;
const server = app.listen(port, '0.0.0.0', () => {
  console.log(`msa-pharmacy-store listening on port ${port}`);
  ensureFirstAdmin().catch((e) => console.error('admin bootstrap skipped:', e.code || e.message));
});

function shutdown() {
  server.close(() => pool.end().finally(() => process.exit(0)));
  setTimeout(() => process.exit(1), 10000).unref();
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
