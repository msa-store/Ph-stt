'use strict';
// دوال تحقق نقية (بدون اعتماديات) قابلة للاختبار.

const AR = '٠١٢٣٤٥٦٧٨٩';
const FA = '۰۱۲۳۴۵۶۷۸۹';
const toLatinDigits = (s) => String(s).replace(/[٠-٩]/g, (d) => AR.indexOf(d)).replace(/[۰-۹]/g, (d) => FA.indexOf(d));
const CTRL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;

function str(v, min, max) {
  if (typeof v !== 'string') return null;
  const s = v.replace(CTRL, '').trim();
  return s.length >= min && s.length <= max ? s : null;
}

function intIn(v, min, max) {
  let n;
  if (typeof v === 'number' && Number.isInteger(v)) n = v;
  else if (typeof v === 'string' && /^\d{1,9}$/.test(v.trim())) n = Number(v.trim());
  else return null;
  return n >= min && n <= max ? n : null;
}

function parseId(v) {
  if (typeof v === 'number') v = String(v);
  if (typeof v !== 'string' || !/^\d{1,15}$/.test(v)) return null;
  const n = Number(v);
  return n > 0 ? n : null;
}

function normalizePhone(v) {
  if (typeof v !== 'string') return null;
  const s = toLatinDigits(v).replace(/[\s\-().]/g, '');
  const m = /^(?:\+?20|0)?(1[0125]\d{8})$/.exec(s);
  return m ? '0' + m[1] : null;
}

// يعيد السعر بالقروش (عدد صحيح) أو null
function parseMoney(v) {
  let s;
  if (typeof v === 'number' && Number.isFinite(v)) s = String(v);
  else if (typeof v === 'string') s = toLatinDigits(v).trim();
  else return null;
  if (!/^\d{1,8}(\.\d{1,2})?$/.test(s)) return null;
  return Math.round(Number(s) * 100);
}
const moneyStr = (cents) => (cents / 100).toFixed(2);

const finish = (value, errors) => ({ ok: Object.keys(errors).length === 0, value, errors });

function validateOrder(body) {
  const b = body && typeof body === 'object' ? body : {};
  const errors = {};
  const value = {};

  value.customerName = str(b.customerName, 2, 100);
  if (!value.customerName) errors.customerName = 'اكتب الاسم (حرفان على الأقل)';

  value.customerPhone = normalizePhone(b.customerPhone);
  if (!value.customerPhone) errors.customerPhone = 'رقم الهاتف غير صحيح (مثال: 01012345678)';

  value.customerAddress = str(b.customerAddress, 8, 500);
  if (!value.customerAddress) errors.customerAddress = 'اكتب العنوان بالتفصيل (8 أحرف على الأقل)';

  if (typeof b.idempotencyKey === 'string' && /^[A-Za-z0-9_-]{16,64}$/.test(b.idempotencyKey)) value.idempotencyKey = b.idempotencyKey;
  else errors.idempotencyKey = 'معرّف الطلب غير صالح';

  const merged = new Map();
  if (!Array.isArray(b.items) || b.items.length < 1 || b.items.length > 50) {
    errors.items = 'السلة فارغة أو عدد المنتجات غير صالح';
  } else {
    for (const it of b.items) {
      const productId = it && parseId(it.productId);
      const quantity = it && intIn(it.quantity, 1, 100);
      if (!productId || !quantity) { errors.items = 'بيانات أحد المنتجات أو كميته غير صالحة'; break; }
      merged.set(productId, (merged.get(productId) || 0) + quantity);
    }
    if (!errors.items) {
      value.items = [...merged].map(([productId, quantity]) => ({ productId, quantity }));
      if (value.items.some((i) => i.quantity > 100)) errors.items = 'الكمية المطلوبة كبيرة جدًا';
    }
  }
  // ملاحظة: أي حقول سعر أو إجمالي قادمة من المتصفح تُتجاهل عمدًا.
  return finish(value, errors);
}

function validateProduct(body, { partial = false } = {}) {
  const b = body && typeof body === 'object' ? body : {};
  const has = (k) => Object.prototype.hasOwnProperty.call(b, k);
  const need = (k) => !partial || has(k);
  const errors = {};
  const value = {};
  let priceC; let oldC;

  if (need('name')) {
    const s = str(b.name, 2, 200);
    if (s === null) errors.name = 'اسم المنتج مطلوب (2-200 حرف)'; else value.name = s;
  }
  if (has('description') || !partial) {
    const d = b.description == null ? '' : str(b.description, 0, 4000);
    if (d === null) errors.description = 'الوصف طويل جدًا (الحد 4000 حرف)'; else value.description = d;
  }
  if (need('price')) {
    const c = parseMoney(b.price);
    if (c === null || c <= 0) errors.price = 'السعر الحالي غير صالح'; else { priceC = c; value.price = moneyStr(c); }
  }
  if (has('oldPrice')) {
    if (b.oldPrice === null || b.oldPrice === '') value.old_price = null;
    else {
      const c = parseMoney(b.oldPrice);
      if (c === null || c <= 0) errors.oldPrice = 'السعر قبل الخصم غير صالح'; else { oldC = c; value.old_price = moneyStr(c); }
    }
  }
  if (priceC !== undefined && oldC !== undefined && oldC <= priceC) errors.oldPrice = 'السعر قبل الخصم يجب أن يكون أكبر من السعر الحالي';

  if (has('imageUrl')) {
    if (b.imageUrl === null || b.imageUrl === '') value.image_url = null;
    else {
      const s = str(b.imageUrl, 1, 1000);
      if (s === null || !/^(https?:\/\/[^\s]+|\/(?!\/)[^\s]*)$/.test(s)) errors.imageUrl = 'رابط الصورة غير صالح';
      else value.image_url = s;
    }
  }
  if (need('category')) {
    const s = str(b.category, 2, 50);
    if (s === null || !/^[a-z0-9-]+$/.test(s)) errors.category = 'القسم مطلوب'; else value.category = s;
  }
  if (has('subcategory')) {
    if (b.subcategory === null || b.subcategory === '') value.subcategory = null;
    else {
      const s = str(b.subcategory, 1, 100);
      if (s === null) errors.subcategory = 'القسم الفرعي غير صالح'; else value.subcategory = s;
    }
  }
  if (has('stock')) {
    const n = intIn(b.stock, 0, 100000);
    if (n === null) errors.stock = 'الكمية يجب أن تكون عددًا صحيحًا من 0 إلى 100000'; else value.stock = n;
  } else if (!partial) value.stock = 0;

  for (const [key, col, def] of [['isOffer', 'is_offer', false], ['isActive', 'is_active', true]]) {
    if (has(key)) {
      if (typeof b[key] !== 'boolean') errors[key] = 'قيمة غير صالحة'; else value[col] = b[key];
    } else if (!partial) value[col] = def;
  }
  return finish(value, errors);
}

function validateCategory(body) {
  const b = body && typeof body === 'object' ? body : {};
  const errors = {};
  const value = {};
  const slug = str(b.slug, 2, 50);
  if (slug === null || !/^[a-z0-9-]+$/.test(slug)) errors.slug = 'المعرّف: حروف إنجليزية صغيرة وأرقام وشرطات فقط';
  else value.slug = slug;
  const name = str(b.name, 2, 60);
  if (name === null) errors.name = 'اسم القسم مطلوب'; else value.name = name;
  const so = b.sortOrder == null || b.sortOrder === '' ? 0 : intIn(b.sortOrder, 0, 1000);
  if (so === null) errors.sortOrder = 'الترتيب غير صالح'; else value.sort_order = so;
  return finish(value, errors);
}

const STATUSES = ['new', 'processing', 'delivered', 'cancelled'];

function validateUsername(u) {
  const s = typeof u === 'string' ? u.trim().toLowerCase() : '';
  return /^[a-z0-9_.-]{3,40}$/.test(s) ? s : null;
}
function validatePassword(p, username) {
  if (typeof p !== 'string' || p.length < 10) return 'كلمة المرور يجب ألا تقل عن 10 أحرف';
  if (Buffer.byteLength(p) > 72) return 'كلمة المرور طويلة جدًا (الحد 72 بايت)';
  if (username && p.toLowerCase() === username.toLowerCase()) return 'كلمة المرور لا يجب أن تطابق اسم المستخدم';
  return null;
}

module.exports = { toLatinDigits, str, intIn, parseId, normalizePhone, parseMoney, moneyStr, validateOrder, validateProduct, validateCategory, validateUsername, validatePassword, STATUSES };
