'use strict';
require('dotenv').config();
const { Pool } = require('pg');

const url = process.env.DATABASE_URL;
const isLocal = /@(localhost|127\.0\.0\.1)(:|\/)/.test(url || '');
// Neon يتطلب SSL. رابط Neon يحتوي sslmode=require فيُترك لمكتبة pg؛ وإلا نفعّل التحقق من الشهادة.
const ssl = !url || isLocal || /sslmode=/.test(url) ? undefined : { rejectUnauthorized: true };

if (!url) console.warn('DATABASE_URL is not set');

const pool = new Pool({
  connectionString: url,
  ssl,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 15000, // Neon قد يحتاج ثوانٍ للاستيقاظ
});
pool.on('error', (e) => console.error('pg pool error:', e.code || e.message));

async function tx(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (e) {
    try { await client.query('ROLLBACK'); } catch (_) { /* connection may be gone */ }
    throw e;
  } finally {
    client.release();
  }
}

module.exports = { pool, tx };
