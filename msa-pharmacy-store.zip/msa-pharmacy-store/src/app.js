'use strict';
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const session = require('express-session');
const PgStore = require('connect-pg-simple')(session);
const rateLimit = require('express-rate-limit');
const { pool } = require('./db');
const { errorHandler, notFoundApi } = require('./http');
const publicRoutes = require('./routes/public');
const adminRoutes = require('./routes/admin');

function createApp() {
  const prod = process.env.NODE_ENV === 'production';
  const secret = process.env.SESSION_SECRET;
  if (prod && (!secret || secret.length < 32)) throw new Error('SESSION_SECRET (32 characters minimum) is required in production');

  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 1); // Render يضع الخادم خلف وكيل

  app.use(helmet({
    contentSecurityPolicy: {
      useDefaults: true,
      directives: {
        'img-src': ["'self'", 'data:', 'https:'],
        'upgrade-insecure-requests': prod ? [] : null,
      },
    },
  }));
  app.use(express.json({ limit: '50kb' }));

  const skipInTest = () => process.env.NODE_ENV === 'test';
  app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: 600, standardHeaders: true, legacyHeaders: false, skip: skipInTest, message: { error: { message: 'طلبات كثيرة، حاول لاحقًا', code: 'RATE_LIMITED' } } }));

  const sessionMw = session({
    name: 'msa.sid',
    secret: secret || 'dev-only-secret-change-me',
    resave: false,
    saveUninitialized: false,
    rolling: true,
    store: new PgStore({ pool, tableName: 'user_sessions', createTableIfMissing: false }),
    cookie: { httpOnly: true, sameSite: 'strict', secure: prod, maxAge: 8 * 60 * 60 * 1000 },
  });

  app.use('/api/admin', sessionMw, adminRoutes);
  app.use('/api', publicRoutes);
  app.use('/api', notFoundApi);

  app.use(express.static(path.join(__dirname, '..', 'public'), { maxAge: '10m', index: 'index.html' }));
  app.use(errorHandler);
  return app;
}

module.exports = { createApp };
