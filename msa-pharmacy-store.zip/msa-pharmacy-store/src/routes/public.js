'use strict';
const express = require('express');
const rateLimit = require('express-rate-limit');
const { pool } = require('../db');
const { HttpError, wrap } = require('../http');
const { mapProduct } = require('../products');
const { createOrder } = require('../orders');
const { validateOrder, parseId } = require('../validate');

const router = express.Router();

router.get('/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ok', db: 'up' });
  } catch (e) {
    res.status(503).json({ status: 'degraded', db: 'down' });
  }
});

router.get('/config', (req, res) => {
  const wa = String(process.env.WHATSAPP_NUMBER || '201010031279').replace(/\D/g, '');
  res.json({ storeName: process.env.STORE_NAME || 'صيدليات محمد سعد', whatsappNumber: wa, currency: 'EGP' });
});

router.get('/categories', wrap(async (req, res) => {
  const { rows } = await pool.query(
    `SELECT c.slug, c.name, c.sort_order, COUNT(p.id) FILTER (WHERE p.is_active)::int AS count
       FROM categories c LEFT JOIN products p ON p.category = c.slug
      GROUP BY c.slug ORDER BY c.sort_order, c.name`,
  );
  res.json({ items: rows.map((r) => ({ slug: r.slug, name: r.name, count: r.count })) });
}));

const SORTS = {
  new: 'p.created_at DESC',
  price_asc: 'p.price ASC',
  price_desc: 'p.price DESC',
};

router.get('/products', wrap(async (req, res) => {
  const where = ['p.is_active = true'];
  const params = [];
  const add = (sql, val) => { params.push(val); where.push(sql.replaceAll('?', '$' + params.length)); };

  if (req.query.ids) {
    const ids = String(req.query.ids).split(',').map(parseId).filter(Boolean).slice(0, 48);
    if (!ids.length) return res.json({ items: [], total: 0, page: 1, pages: 0 });
    add('p.id = ANY(?::bigint[])', ids);
  }
  const cat = typeof req.query.category === 'string' ? req.query.category : '';
  if (/^[a-z0-9-]{2,50}$/.test(cat)) add('p.category = ?', cat);
  const q = typeof req.query.q === 'string' ? req.query.q.trim().slice(0, 100) : '';
  if (q) add('(p.name ILIKE ? OR p.description ILIKE ? OR p.subcategory ILIKE ?)', '%' + q.replace(/[\\%_]/g, '\\$&') + '%');
  if (req.query.offer === '1') where.push('p.is_offer = true');

  const order = SORTS[req.query.sort] || SORTS.new;
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 12, 1), 48);
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const whereSql = where.join(' AND ');

  const count = await pool.query(`SELECT COUNT(*)::int AS n FROM products p WHERE ${whereSql}`, params);
  const rows = await pool.query(
    `SELECT p.* FROM products p WHERE ${whereSql} ORDER BY ${order}, p.id DESC LIMIT ${limit} OFFSET ${(page - 1) * limit}`,
    params,
  );
  const total = count.rows[0].n;
  res.json({ items: rows.rows.map(mapProduct), total, page, pages: Math.ceil(total / limit) });
}));

router.get('/products/:id', wrap(async (req, res) => {
  const id = parseId(req.params.id);
  if (!id) throw new HttpError(400, 'رقم المنتج غير صالح', 'BAD_ID');
  const { rows } = await pool.query('SELECT * FROM products WHERE id = $1 AND is_active = true', [id]);
  if (!rows[0]) throw new HttpError(404, 'المنتج غير موجود أو غير متاح', 'NOT_FOUND');
  res.json({ product: mapProduct(rows[0]) });
}));

const orderLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 15, standardHeaders: true, legacyHeaders: false,
  skip: () => process.env.NODE_ENV === 'test',
  message: { error: { message: 'محاولات طلب كثيرة. انتظر قليلًا ثم حاول مرة أخرى.', code: 'RATE_LIMITED' } },
});

router.post('/orders', orderLimiter, wrap(async (req, res) => {
  const v = validateOrder(req.body);
  if (!v.ok) throw new HttpError(400, 'تحقق من البيانات المدخلة', 'VALIDATION', { fields: v.errors });
  const { order, duplicate } = await createOrder(v.value);
  res.status(duplicate ? 200 : 201).json({
    order,
    duplicate,
    notice: 'تم حفظ الطلب في النظام. إرسال الرسالة عبر واتساب يحتاج إتمامك له، وتأكيد الصيدلية للطلب مرحلة منفصلة.',
  });
}));

module.exports = router;
