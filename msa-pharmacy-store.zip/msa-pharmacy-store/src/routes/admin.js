'use strict';
const express = require('express');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const { pool } = require('../db');
const { HttpError, wrap } = require('../http');
const { mapProduct } = require('../products');
const { mapOrder, fetchOrder, changeStatus } = require('../orders');
const V = require('../validate');

const router = express.Router();
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password-for-timing', 12);

// حماية CSRF: الكوكي SameSite=Strict + اشتراط ترويسة مخصصة لكل عملية تعديل
router.use((req, res, next) => {
  if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method) && req.get('x-requested-with') !== 'msa-admin') {
    return next(new HttpError(403, 'طلب مرفوض', 'CSRF'));
  }
  next();
});

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 10, skipSuccessfulRequests: true, standardHeaders: true, legacyHeaders: false,
  message: { error: { message: 'محاولات دخول كثيرة. حاول بعد 15 دقيقة.', code: 'RATE_LIMITED' } },
});

const saveSession = (req) => new Promise((resolve, reject) => req.session.save((e) => (e ? reject(e) : resolve())));
const regenSession = (req) => new Promise((resolve, reject) => req.session.regenerate((e) => (e ? reject(e) : resolve())));

router.post('/login', loginLimiter, wrap(async (req, res) => {
  const username = String(req.body && req.body.username || '').trim().toLowerCase().slice(0, 40);
  const password = String(req.body && req.body.password || '').slice(0, 200);
  const { rows } = await pool.query('SELECT id, username, password_hash FROM admin_users WHERE username = $1', [username]);
  const match = await bcrypt.compare(password, rows[0] ? rows[0].password_hash : DUMMY_HASH);
  if (!rows[0] || !match) throw new HttpError(401, 'اسم المستخدم أو كلمة المرور غير صحيحة', 'INVALID_CREDENTIALS');
  await regenSession(req);
  req.session.adminId = Number(rows[0].id);
  req.session.adminUser = rows[0].username;
  await saveSession(req);
  res.json({ ok: true, username: rows[0].username });
}));

router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('msa.sid');
    res.json({ ok: true });
  });
});

router.get('/me', (req, res) => {
  if (!req.session || !req.session.adminId) return res.status(401).json({ error: { message: 'غير مسجل الدخول', code: 'UNAUTHORIZED' } });
  res.json({ authenticated: true, username: req.session.adminUser });
});

// ---- كل ما بعد هذا السطر يتطلب جلسة مدير صالحة (التحقق على الخادم) ----
router.use((req, res, next) => {
  if (!req.session || !req.session.adminId) return next(new HttpError(401, 'يجب تسجيل الدخول', 'UNAUTHORIZED'));
  next();
});

router.post('/password', wrap(async (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  const { rows } = await pool.query('SELECT id, username, password_hash FROM admin_users WHERE id = $1', [req.session.adminId]);
  if (!rows[0] || !(await bcrypt.compare(String(currentPassword || ''), rows[0].password_hash))) {
    throw new HttpError(400, 'كلمة المرور الحالية غير صحيحة', 'INVALID_CREDENTIALS');
  }
  const problem = V.validatePassword(newPassword, rows[0].username);
  if (problem) throw new HttpError(400, problem, 'WEAK_PASSWORD');
  await pool.query('UPDATE admin_users SET password_hash = $1 WHERE id = $2', [await bcrypt.hash(newPassword, 12), rows[0].id]);
  const { adminId, adminUser } = req.session;
  await regenSession(req);
  req.session.adminId = adminId;
  req.session.adminUser = adminUser;
  await saveSession(req);
  // إنهاء كل الجلسات الأخرى لنفس المدير
  await pool.query("DELETE FROM user_sessions WHERE (sess->>'adminId')::bigint = $1 AND sid <> $2", [adminId, req.sessionID]);
  res.json({ ok: true });
}));

router.get('/stats', wrap(async (req, res) => {
  const { rows } = await pool.query(`
    SELECT
      (SELECT COUNT(*) FROM orders WHERE status = 'new')::int AS new_orders,
      (SELECT COUNT(*) FROM orders)::int AS total_orders,
      (SELECT COALESCE(SUM(total),0) FROM orders WHERE status <> 'cancelled') AS sales,
      (SELECT COUNT(*) FROM products)::int AS products,
      (SELECT COUNT(*) FROM products WHERE stock <= 5 AND is_active)::int AS low_stock`);
  const r = rows[0];
  res.json({ newOrders: r.new_orders, totalOrders: r.total_orders, sales: Number(r.sales), products: r.products, lowStock: r.low_stock });
}));

// ---------- الطلبات ----------
router.get('/orders', wrap(async (req, res) => {
  const where = [];
  const params = [];
  const add = (sql, val) => { params.push(val); where.push(sql.replaceAll('?', '$' + params.length)); };
  if (V.STATUSES.includes(req.query.status)) add('o.status = ?', req.query.status);
  const q = typeof req.query.q === 'string' ? V.toLatinDigits(req.query.q).trim().slice(0, 100) : '';
  if (q) {
    const like = '%' + q.replace(/[\\%_]/g, '\\$&') + '%';
    params.push(like);
    let cond = `(o.customer_name ILIKE $${params.length} OR o.customer_phone LIKE $${params.length}`;
    const idQ = V.parseId(q.replace(/^#/, ''));
    if (idQ) { params.push(idQ); cond += ` OR o.id = $${params.length}`; }
    where.push(cond + ')');
  }
  const dateRe = /^\d{4}-\d{2}-\d{2}$/;
  if (dateRe.test(req.query.from || '')) add("o.created_at >= (?::date)::timestamp AT TIME ZONE 'Africa/Cairo'", req.query.from);
  if (dateRe.test(req.query.to || '')) add("o.created_at < ((?::date) + 1)::timestamp AT TIME ZONE 'Africa/Cairo'", req.query.to);
  const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 100);
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const count = await pool.query(`SELECT COUNT(*)::int AS n FROM orders o ${whereSql}`, params);
  const rows = await pool.query(
    `SELECT o.*, (SELECT COALESCE(SUM(quantity),0)::int FROM order_items i WHERE i.order_id = o.id) AS item_count
       FROM orders o ${whereSql} ORDER BY o.created_at DESC, o.id DESC LIMIT ${limit} OFFSET ${(page - 1) * limit}`,
    params,
  );
  const total = count.rows[0].n;
  res.json({
    items: rows.rows.map((r) => ({ ...mapOrder(r), itemCount: r.item_count })),
    total, page, pages: Math.ceil(total / limit),
  });
}));

router.get('/orders/:id', wrap(async (req, res) => {
  const id = V.parseId(req.params.id);
  if (!id) throw new HttpError(400, 'رقم الطلب غير صالح', 'BAD_ID');
  const order = await fetchOrder(pool, 'id = $1', id);
  if (!order) throw new HttpError(404, 'الطلب غير موجود', 'NOT_FOUND');
  res.json({ order });
}));

router.patch('/orders/:id/status', wrap(async (req, res) => {
  const id = V.parseId(req.params.id);
  if (!id) throw new HttpError(400, 'رقم الطلب غير صالح', 'BAD_ID');
  const status = req.body && req.body.status;
  if (!V.STATUSES.includes(status)) throw new HttpError(400, 'حالة الطلب غير صالحة', 'VALIDATION');
  res.json({ order: await changeStatus(id, status) });
}));

// ---------- المنتجات ----------
router.get('/products', wrap(async (req, res) => {
  const where = [];
  const params = [];
  const q = typeof req.query.q === 'string' ? req.query.q.trim().slice(0, 100) : '';
  if (q) { params.push('%' + q.replace(/[\\%_]/g, '\\$&') + '%'); where.push(`(name ILIKE $${params.length} OR description ILIKE $${params.length})`); }
  const cat = typeof req.query.category === 'string' ? req.query.category : '';
  if (/^[a-z0-9-]{2,50}$/.test(cat)) { params.push(cat); where.push(`category = $${params.length}`); }
  const { rows } = await pool.query(`SELECT * FROM products ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY id DESC LIMIT 500`, params);
  res.json({ items: rows.map(mapProduct) });
}));

router.post('/products', wrap(async (req, res) => {
  const v = V.validateProduct(req.body);
  if (!v.ok) throw new HttpError(400, 'تحقق من بيانات المنتج', 'VALIDATION', { fields: v.errors });
  const x = v.value;
  const { rows } = await pool.query(
    `INSERT INTO products (name, description, price, old_price, image_url, category, subcategory, stock, is_offer, is_active)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
    [x.name, x.description, x.price, x.old_price ?? null, x.image_url ?? null, x.category, x.subcategory ?? null, x.stock, x.is_offer, x.is_active],
  );
  res.status(201).json({ product: mapProduct(rows[0]) });
}));

router.patch('/products/:id', wrap(async (req, res) => {
  const id = V.parseId(req.params.id);
  if (!id) throw new HttpError(400, 'رقم المنتج غير صالح', 'BAD_ID');
  const v = V.validateProduct(req.body, { partial: true });
  if (!v.ok) throw new HttpError(400, 'تحقق من بيانات المنتج', 'VALIDATION', { fields: v.errors });
  const cols = Object.keys(v.value); // مفاتيح من قائمة بيضاء داخل validateProduct فقط
  if (!cols.length) throw new HttpError(400, 'لا توجد حقول للتعديل', 'VALIDATION');
  const sets = cols.map((c, i) => `${c} = $${i + 1}`);
  const { rows } = await pool.query(
    `UPDATE products SET ${sets.join(', ')} WHERE id = $${cols.length + 1} RETURNING *`,
    [...cols.map((c) => v.value[c]), id],
  );
  if (!rows[0]) throw new HttpError(404, 'المنتج غير موجود', 'NOT_FOUND');
  res.json({ product: mapProduct(rows[0]) });
}));

router.delete('/products/:id', wrap(async (req, res) => {
  const id = V.parseId(req.params.id);
  if (!id) throw new HttpError(400, 'رقم المنتج غير صالح', 'BAD_ID');
  const { rowCount } = await pool.query('DELETE FROM products WHERE id = $1', [id]);
  if (!rowCount) throw new HttpError(404, 'المنتج غير موجود', 'NOT_FOUND');
  res.json({ ok: true });
}));

// ---------- الأقسام ----------
router.post('/categories', wrap(async (req, res) => {
  const v = V.validateCategory(req.body);
  if (!v.ok) throw new HttpError(400, 'تحقق من بيانات القسم', 'VALIDATION', { fields: v.errors });
  const { rows } = await pool.query(
    'INSERT INTO categories (slug, name, sort_order) VALUES ($1,$2,$3) RETURNING slug, name, sort_order',
    [v.value.slug, v.value.name, v.value.sort_order],
  );
  res.status(201).json({ category: rows[0] });
}));

router.patch('/categories/:slug', wrap(async (req, res) => {
  const slug = String(req.params.slug);
  if (!/^[a-z0-9-]{2,50}$/.test(slug)) throw new HttpError(400, 'معرّف القسم غير صالح', 'BAD_ID');
  const v = V.validateCategory({ slug, name: req.body && req.body.name, sortOrder: req.body && req.body.sortOrder });
  if (!v.ok) throw new HttpError(400, 'تحقق من بيانات القسم', 'VALIDATION', { fields: v.errors });
  const { rows } = await pool.query('UPDATE categories SET name = $1, sort_order = $2 WHERE slug = $3 RETURNING slug, name, sort_order', [v.value.name, v.value.sort_order, slug]);
  if (!rows[0]) throw new HttpError(404, 'القسم غير موجود', 'NOT_FOUND');
  res.json({ category: rows[0] });
}));

module.exports = router;
