'use strict';

class HttpError extends Error {
  constructor(status, message, code, extra) {
    super(message);
    this.status = status;
    this.code = code;
    this.extra = extra || {};
  }
}

const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const CONN_CODES = new Set(['ECONNREFUSED', 'ETIMEDOUT', 'ENOTFOUND', 'ECONNRESET', 'EAI_AGAIN', '57P01', '57P03', '08000', '08001', '08003', '08006']);

function errorHandler(err, req, res, next) { // eslint-disable-line no-unused-vars
  if (res.headersSent) return next(err);
  let status = 500;
  let message = 'حدث خطأ في الخادم. حاول مرة أخرى لاحقًا.';
  let code = 'INTERNAL';
  let extra = {};

  if (err instanceof HttpError) {
    status = err.status; message = err.message; code = err.code || 'ERROR'; extra = err.extra;
  } else if (err && err.type === 'entity.parse.failed') {
    status = 400; message = 'صيغة البيانات المرسلة غير صحيحة'; code = 'BAD_JSON';
  } else if (err && err.type === 'entity.too.large') {
    status = 413; message = 'حجم الطلب كبير جدًا'; code = 'TOO_LARGE';
  } else if (err && (CONN_CODES.has(err.code) || /timeout|Connection terminated|connect/i.test(err.message || ''))) {
    status = 503; message = 'الخدمة غير متاحة مؤقتًا. حاول بعد قليل.'; code = 'DB_UNAVAILABLE';
  } else if (err && err.code === '23505') {
    status = 409; message = 'القيمة مكررة (موجودة مسبقًا)'; code = 'DUPLICATE';
  } else if (err && err.code === '23503') {
    status = 400; message = 'القسم أو المرجع المحدد غير موجود'; code = 'BAD_REFERENCE';
  } else if (err && ['23514', '22P02', '22003', '23502'].includes(err.code)) {
    status = 400; message = 'بيانات غير صالحة (راجع الأسعار والكميات)'; code = 'BAD_DATA';
  }

  if (status >= 500) console.error('request failed:', req.method, req.path, err && (err.code || err.name), err && err.message);
  res.status(status).json({ error: { message, code, ...extra } });
}

function notFoundApi(req, res) {
  res.status(404).json({ error: { message: 'المسار غير موجود', code: 'NOT_FOUND' } });
}

module.exports = { HttpError, wrap, errorHandler, notFoundApi };
