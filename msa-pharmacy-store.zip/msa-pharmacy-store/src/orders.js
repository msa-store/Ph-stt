'use strict';
const { pool, tx } = require('./db');
const { HttpError } = require('./http');

const cents = (v) => Math.round(Number(v) * 100);
const money = (c) => (c / 100).toFixed(2);

const mapItem = (i) => ({
  id: Number(i.id),
  productId: i.product_id == null ? null : Number(i.product_id),
  name: i.product_name,
  quantity: i.quantity,
  unitPrice: Number(i.unit_price),
  oldUnitPrice: i.old_unit_price == null ? null : Number(i.old_unit_price),
  lineTotal: Number(i.line_total),
});
const mapOrder = (o, items) => ({
  id: Number(o.id),
  status: o.status,
  customerName: o.customer_name,
  customerPhone: o.customer_phone,
  customerAddress: o.customer_address,
  subtotal: Number(o.subtotal),
  discount: Number(o.discount),
  total: Number(o.total),
  createdAt: o.created_at,
  updatedAt: o.updated_at,
  items: items ? items.map(mapItem) : undefined,
});

// `where` نص ثابت من الكود فقط (لا يأتي من المستخدم)
async function fetchOrder(db, where, param, forUpdate = false) {
  const { rows } = await db.query(`SELECT * FROM orders WHERE ${where}${forUpdate ? ' FOR UPDATE' : ''}`, [param]);
  if (!rows[0]) return null;
  const items = await db.query('SELECT * FROM order_items WHERE order_id = $1 ORDER BY id', [rows[0].id]);
  return mapOrder(rows[0], items.rows);
}

async function createOrder(v) {
  try {
    return await tx(async (db) => {
      const dup = await fetchOrder(db, 'idempotency_key = $1', v.idempotencyKey);
      if (dup) return { order: dup, duplicate: true };

      const ids = v.items.map((i) => i.productId);
      // قفل صفوف المنتجات (بترتيب ثابت لتفادي deadlock) لضمان سلامة المخزون مع الطلبات المتزامنة
      const { rows } = await db.query(
        'SELECT id, name, price, old_price, stock, is_active FROM products WHERE id = ANY($1::bigint[]) ORDER BY id FOR UPDATE',
        [ids],
      );
      const byId = new Map(rows.map((r) => [Number(r.id), r]));
      const problems = [];
      for (const it of v.items) {
        const p = byId.get(it.productId);
        if (!p || !p.is_active) problems.push({ productId: it.productId, name: p ? p.name : null, available: 0 });
        else if (p.stock < it.quantity) problems.push({ productId: it.productId, name: p.name, available: p.stock });
      }
      if (problems.length) {
        throw new HttpError(409, 'بعض المنتجات غير متاحة بالكمية المطلوبة. راجع السلة وحاول مرة أخرى.', 'STOCK_CONFLICT', { details: problems });
      }

      let subtotal = 0;
      let total = 0;
      const lines = v.items.map((it) => {
        const p = byId.get(it.productId);
        const unit = cents(p.price);
        const old = p.old_price != null ? cents(p.old_price) : null;
        subtotal += (old != null ? old : unit) * it.quantity;
        total += unit * it.quantity;
        return { p, qty: it.quantity, unit, old };
      });
      const discount = subtotal - total;

      const ins = await db.query(
        `INSERT INTO orders (customer_name, customer_phone, customer_address, subtotal, discount, total, status, idempotency_key)
         VALUES ($1,$2,$3,$4,$5,$6,'new',$7) RETURNING id`,
        [v.customerName, v.customerPhone, v.customerAddress, money(subtotal), money(discount), money(total), v.idempotencyKey],
      );
      const orderId = ins.rows[0].id;

      for (const l of lines) {
        await db.query(
          `INSERT INTO order_items (order_id, product_id, product_name, quantity, unit_price, old_unit_price, line_total)
           VALUES ($1,$2,$3,$4,$5,$6,$7)`,
          [orderId, l.p.id, l.p.name, l.qty, money(l.unit), l.old != null ? money(l.old) : null, money(l.unit * l.qty)],
        );
        const upd = await db.query('UPDATE products SET stock = stock - $1 WHERE id = $2 AND stock >= $1', [l.qty, l.p.id]);
        if (upd.rowCount !== 1) throw new HttpError(409, 'تغيّر المخزون أثناء الطلب. حاول مرة أخرى.', 'STOCK_CONFLICT');
      }
      return { order: await fetchOrder(db, 'id = $1', orderId), duplicate: false };
    });
  } catch (e) {
    // سباق نادر: طلبان بنفس المفتاح في نفس اللحظة
    if (e && e.code === '23505' && /idempotency/.test(e.constraint || '')) {
      const o = await fetchOrder(pool, 'idempotency_key = $1', v.idempotencyKey);
      if (o) return { order: o, duplicate: true };
    }
    throw e;
  }
}

async function changeStatus(id, status) {
  return tx(async (db) => {
    const cur = await fetchOrder(db, 'id = $1', id, true);
    if (!cur) throw new HttpError(404, 'الطلب غير موجود', 'NOT_FOUND');
    if (cur.status === status) return cur;
    if (cur.status === 'cancelled') throw new HttpError(409, 'لا يمكن تغيير حالة طلب ملغي', 'ORDER_CANCELLED');
    if (status === 'cancelled') {
      // إرجاع المخزون عند الإلغاء (مرة واحدة فقط)
      for (const it of cur.items) {
        if (it.productId != null) await db.query('UPDATE products SET stock = stock + $1 WHERE id = $2', [it.quantity, it.productId]);
      }
    }
    await db.query('UPDATE orders SET status = $1 WHERE id = $2', [status, id]);
    return fetchOrder(db, 'id = $1', id);
  });
}

module.exports = { createOrder, changeStatus, fetchOrder, mapOrder };
