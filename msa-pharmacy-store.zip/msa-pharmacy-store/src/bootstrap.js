'use strict';
const bcrypt = require('bcryptjs');
const { pool } = require('./db');
const { validateUsername, validatePassword } = require('./validate');

// ينشئ المدير الأول من متغيرات البيئة فقط إذا لم يوجد أي مدير. لا يطبع كلمة المرور أبدًا.
async function ensureFirstAdmin() {
  const rawUser = process.env.ADMIN_USERNAME;
  const pass = process.env.ADMIN_PASSWORD;
  if (!rawUser || !pass) return;
  const { rows } = await pool.query('SELECT 1 FROM admin_users LIMIT 1');
  if (rows.length) return;
  const username = validateUsername(rawUser);
  const problem = !username ? 'ADMIN_USERNAME غير صالح (3-40 حرفًا إنجليزيًا/أرقام/_ . -)' : validatePassword(pass, username);
  if (problem) { console.warn('first admin NOT created:', problem); return; }
  const hash = await bcrypt.hash(pass, 12);
  await pool.query('INSERT INTO admin_users (username, password_hash) VALUES ($1,$2) ON CONFLICT DO NOTHING', [username, hash]);
  console.log(`first admin created (username: ${username}). Remove ADMIN_PASSWORD from the environment now.`);
}
module.exports = { ensureFirstAdmin };
