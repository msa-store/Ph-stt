'use strict';
const mapProduct = (r) => {
  const price = Number(r.price);
  const oldPrice = r.old_price == null ? null : Number(r.old_price);
  return {
    id: Number(r.id),
    name: r.name,
    description: r.description,
    price,
    oldPrice,
    discountPercent: oldPrice && oldPrice > price ? Math.round(((oldPrice - price) / oldPrice) * 100) : 0,
    imageUrl: r.image_url,
    category: r.category,
    subcategory: r.subcategory,
    stock: r.stock,
    isOffer: r.is_offer,
    isActive: r.is_active,
    isSample: r.is_sample,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
};
module.exports = { mapProduct };
