-- صيدليات محمد سعد - مخطط قاعدة البيانات (PostgreSQL / Neon)
-- آمن لإعادة التشغيل: لا يحذف أي بيانات.

CREATE TABLE IF NOT EXISTS categories (
  slug        text PRIMARY KEY CHECK (slug ~ '^[a-z0-9-]{2,50}$'),
  name        text NOT NULL UNIQUE CHECK (char_length(name) BETWEEN 2 AND 60),
  sort_order  integer NOT NULL DEFAULT 0,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS products (
  id           bigserial PRIMARY KEY,
  name         text NOT NULL CHECK (char_length(name) BETWEEN 2 AND 200),
  description  text NOT NULL DEFAULT '',
  price        numeric(10,2) NOT NULL CHECK (price > 0),
  old_price    numeric(10,2) CHECK (old_price IS NULL OR old_price > price),
  image_url    text,
  category     text NOT NULL REFERENCES categories(slug) ON UPDATE CASCADE ON DELETE RESTRICT,
  subcategory  text,
  stock        integer NOT NULL DEFAULT 0 CHECK (stock >= 0),
  is_offer     boolean NOT NULL DEFAULT false,
  is_active    boolean NOT NULL DEFAULT true,
  is_sample    boolean NOT NULL DEFAULT false,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS products_name_uq ON products (lower(name));
CREATE INDEX IF NOT EXISTS products_category_idx ON products (category, is_active);
CREATE INDEX IF NOT EXISTS products_offer_idx ON products (is_offer) WHERE is_offer;
CREATE INDEX IF NOT EXISTS products_created_idx ON products (created_at DESC);

CREATE TABLE IF NOT EXISTS orders (
  id                bigserial PRIMARY KEY,
  customer_name     text NOT NULL CHECK (char_length(customer_name) BETWEEN 2 AND 100),
  customer_phone    text NOT NULL CHECK (customer_phone ~ '^01[0125][0-9]{8}$'),
  customer_address  text NOT NULL CHECK (char_length(customer_address) BETWEEN 8 AND 500),
  subtotal          numeric(12,2) NOT NULL CHECK (subtotal >= 0),
  discount          numeric(12,2) NOT NULL DEFAULT 0 CHECK (discount >= 0),
  total             numeric(12,2) NOT NULL CHECK (total >= 0),
  status            text NOT NULL DEFAULT 'new' CHECK (status IN ('new','processing','delivered','cancelled')),
  idempotency_key   text NOT NULL,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT orders_idempotency_key_uq UNIQUE (idempotency_key),
  CONSTRAINT orders_total_chk CHECK (total = subtotal - discount)
);
CREATE INDEX IF NOT EXISTS orders_status_created_idx ON orders (status, created_at DESC);
CREATE INDEX IF NOT EXISTS orders_created_idx ON orders (created_at DESC);
CREATE INDEX IF NOT EXISTS orders_phone_idx ON orders (customer_phone);

CREATE TABLE IF NOT EXISTS order_items (
  id              bigserial PRIMARY KEY,
  order_id        bigint NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id      bigint REFERENCES products(id) ON DELETE SET NULL,
  product_name    text NOT NULL,
  quantity        integer NOT NULL CHECK (quantity > 0),
  unit_price      numeric(10,2) NOT NULL CHECK (unit_price >= 0),
  old_unit_price  numeric(10,2),
  line_total      numeric(12,2) NOT NULL CHECK (line_total >= 0),
  CONSTRAINT order_items_line_chk CHECK (line_total = unit_price * quantity)
);
CREATE INDEX IF NOT EXISTS order_items_order_idx ON order_items (order_id);
CREATE INDEX IF NOT EXISTS order_items_product_idx ON order_items (product_id);

CREATE TABLE IF NOT EXISTS admin_users (
  id             bigserial PRIMARY KEY,
  username       text NOT NULL UNIQUE CHECK (username ~ '^[a-z0-9_.-]{3,40}$'),
  password_hash  text NOT NULL,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);

-- جلسات المدير (connect-pg-simple)
CREATE TABLE IF NOT EXISTS user_sessions (
  sid     varchar NOT NULL PRIMARY KEY,
  sess    json NOT NULL,
  expire  timestamp(6) NOT NULL
);
CREATE INDEX IF NOT EXISTS user_sessions_expire_idx ON user_sessions (expire);

CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS products_set_updated_at ON products;
CREATE TRIGGER products_set_updated_at BEFORE UPDATE ON products FOR EACH ROW EXECUTE FUNCTION set_updated_at();
DROP TRIGGER IF EXISTS orders_set_updated_at ON orders;
CREATE TRIGGER orders_set_updated_at BEFORE UPDATE ON orders FOR EACH ROW EXECUTE FUNCTION set_updated_at();
DROP TRIGGER IF EXISTS admin_users_set_updated_at ON admin_users;
CREATE TRIGGER admin_users_set_updated_at BEFORE UPDATE ON admin_users FOR EACH ROW EXECUTE FUNCTION set_updated_at();
